<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirLogin();

// ---------- Acções (POST) ----------
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $acao = $_POST['acao'] ?? '';

    if($acao === 'salvar'){
        $id = (int)($_POST['id'] ?? 0);
        $idCliente = (int)$_POST['id_cliente'];
        $idServico = (int)$_POST['id_servico'];
        $idFunc = $_POST['id_funcionaria'] !== '' ? (int)$_POST['id_funcionaria'] : null;
        $data = $_POST['data'];
        $horaVal = $_POST['hora'];
        $estado = $_POST['estado'];
        $obs = trim($_POST['observacoes'] ?? '');

        $stmtServ = $pdo->prepare("SELECT preco FROM servicos WHERE id = ?");
        $stmtServ->execute([$idServico]);
        $servico = $stmtServ->fetch();
        $valor = $servico ? $servico['preco'] : 0;

        if($id){
            $stmt = $pdo->prepare("UPDATE agendamentos SET id_cliente=?, id_servico=?, id_funcionaria=?, data=?, hora=?, estado=?, valor=?, observacoes=? WHERE id=?");
            $stmt->execute([$idCliente,$idServico,$idFunc,$data,$horaVal,$estado,$valor,$obs,$id]);
            setFlash('Agendamento actualizado!');
        } else {
            $stmt = $pdo->prepare("INSERT INTO agendamentos (id_cliente,id_servico,id_funcionaria,data,hora,estado,valor,observacoes) VALUES (?,?,?,?,?,?,?,?)");
            $stmt->execute([$idCliente,$idServico,$idFunc,$data,$horaVal,$estado,$valor,$obs]);
            setFlash('Agendamento criado!');
        }
        redirecionar('agendamentos.php');
    }

    if($acao === 'estado'){
        $id = (int)$_POST['id'];
        $novoEstado = $_POST['novo_estado'];
        $stmt = $pdo->prepare("UPDATE agendamentos SET estado=? WHERE id=?");
        $stmt->execute([$novoEstado, $id]);
        setFlash('Estado actualizado!');
        redirecionar('agendamentos.php');
    }

    if($acao === 'apagar'){
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM agendamentos WHERE id=?");
        $stmt->execute([$id]);
        setFlash('Agendamento apagado.','warn');
        redirecionar('agendamentos.php');
    }
}

// ---------- Listagem / filtros ----------
$filtroData = $_GET['data'] ?? '';
$filtroEstado = $_GET['estado'] ?? '';
$busca = trim($_GET['q'] ?? '');

$sql = "SELECT a.*, c.nome AS nome_cliente, c.telefone, s.nome AS nome_servico, f.nome AS nome_funcionaria
        FROM agendamentos a
        JOIN clientes c ON c.id = a.id_cliente
        JOIN servicos s ON s.id = a.id_servico
        LEFT JOIN funcionarios f ON f.id = a.id_funcionaria
        WHERE 1=1";
$params = [];
if($filtroData){ $sql .= " AND a.data = ?"; $params[] = $filtroData; }
if($filtroEstado){ $sql .= " AND a.estado = ?"; $params[] = $filtroEstado; }
if($busca){ $sql .= " AND c.nome LIKE ?"; $params[] = "%$busca%"; }
$sql .= " ORDER BY a.data DESC, a.hora DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$agendamentos = $stmt->fetchAll();

$clientes = $pdo->query("SELECT id, nome FROM clientes ORDER BY nome ASC")->fetchAll();
$servicos = $pdo->query("SELECT id, nome, preco FROM servicos ORDER BY nome ASC")->fetchAll();
$funcionarias = $pdo->query("SELECT id, nome FROM funcionarios WHERE estado='activa' ORDER BY nome ASC")->fetchAll();
$nomeSalao = getConfig($pdo, 'nome_salao', 'Magnólia Beauty Salon');

$paginaAtiva = 'agendamentos';
$tituloPagina = 'Agendamentos';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Agendamentos</div><div class="section-sub">Gestão de marcações do salão</div></div>
  <button class="btn btn-primary" onclick="abrirNovoAgendamento()">+ Novo Agendamento</button>
</div>

<form method="GET" class="filters" style="margin-bottom:14px;display:flex;gap:8px;flex-wrap:wrap;">
  <input type="text" name="q" placeholder="Procurar cliente..." value="<?= h($busca) ?>" style="flex:1;min-width:160px;">
  <input type="date" name="data" value="<?= h($filtroData) ?>">
  <select name="estado">
    <option value="">Todos os estados</option>
    <?php foreach(['pendente','confirmado','concluido','cancelado'] as $e): ?>
      <option value="<?= $e ?>" <?= $filtroEstado===$e?'selected':'' ?>><?= ucfirst($e) ?></option>
    <?php endforeach; ?>
  </select>
  <button class="btn btn-ghost" type="submit">Filtrar</button>
</form>

<div class="table-wrap">
  <table>
    <thead><tr><th>Data</th><th>Hora</th><th>Cliente</th><th>Serviço</th><th>Profissional</th><th>Valor</th><th>Estado</th><th>Acções</th></tr></thead>
    <tbody>
      <?php if(!$agendamentos): ?>
        <tr><td colspan="8"><div class="empty"><div class="empty-icon">◷</div><div class="empty-text">Nenhum agendamento encontrado</div></div></td></tr>
      <?php else: foreach($agendamentos as $a): ?>
        <tr>
          <td><?= fmtDataBR($a['data']) ?></td>
          <td><?= substr($a['hora'],0,5) ?></td>
          <td class="td-main"><?= h($a['nome_cliente']) ?></td>
          <td><?= h($a['nome_servico']) ?></td>
          <td><?= h($a['nome_funcionaria'] ?? '—') ?></td>
          <td><?= fmtKz($a['valor']) ?></td>
          <td><?= badgeEstadoAgendamento($a['estado']) ?></td>
          <td>
            <div class="actions" style="display:flex;gap:6px;flex-wrap:wrap;">
              <button class="action-btn" title="Editar" onclick='abrirEditarAgendamento(<?= json_encode($a) ?>)'>✎</button>
              <button class="action-btn" title="Lembrete WhatsApp" onclick="lembreteWA('<?= formatarTelWhatsApp($a['telefone']) ?>','<?= h(addslashes($a['nome_cliente'])) ?>','<?= h(addslashes($a['nome_servico'])) ?>','<?= fmtDataBR($a['data']) ?>','<?= substr($a['hora'],0,5) ?>')">💬</button>
              <?php if($a['estado'] !== 'concluido'): ?>
              <form method="POST" style="display:inline;">
                <input type="hidden" name="acao" value="estado">
                <input type="hidden" name="id" value="<?= $a['id'] ?>">
                <input type="hidden" name="novo_estado" value="concluido">
                <button class="action-btn" title="Marcar concluído" type="submit">✓</button>
              </form>
              <?php endif; ?>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Apagar este agendamento?');">
                <input type="hidden" name="acao" value="apagar">
                <input type="hidden" name="id" value="<?= $a['id'] ?>">
                <button class="action-btn del" title="Apagar" type="submit">🗑</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<!-- MODAL: NOVO/EDITAR AGENDAMENTO -->
<div class="modal-overlay" id="modal-agendamento">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title" id="modal-ag-title">Novo Agendamento</div>
      <button class="modal-close" onclick="fecharModal('modal-agendamento')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="acao" value="salvar">
        <input type="hidden" name="id" id="ag-id">
        <div class="form-group">
          <label>Cliente <span class="req">*</span></label>
          <select name="id_cliente" id="ag-cliente" required>
            <option value="">-- Seleccionar --</option>
            <?php foreach($clientes as $c): ?>
              <option value="<?= $c['id'] ?>"><?= h($c['nome']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Serviço <span class="req">*</span></label>
          <select name="id_servico" id="ag-servico" required>
            <option value="">-- Seleccionar --</option>
            <?php foreach($servicos as $s): ?>
              <option value="<?= $s['id'] ?>"><?= h($s['nome']) ?> (<?= fmtKz($s['preco']) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Profissional</label>
          <select name="id_funcionaria" id="ag-funcionaria">
            <option value="">-- Sem preferência --</option>
            <?php foreach($funcionarias as $f): ?>
              <option value="<?= $f['id'] ?>"><?= h($f['nome']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Data <span class="req">*</span></label><input type="date" name="data" id="ag-data" required></div>
          <div class="form-group"><label>Hora <span class="req">*</span></label><input type="time" name="hora" id="ag-hora" required></div>
        </div>
        <div class="form-group">
          <label>Estado</label>
          <select name="estado" id="ag-estado">
            <option value="pendente">Pendente</option>
            <option value="confirmado">Confirmado</option>
            <option value="concluido">Concluído</option>
            <option value="cancelado">Cancelado</option>
          </select>
        </div>
        <div class="form-group"><label>Observações</label><textarea name="observacoes" id="ag-obs"></textarea></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="fecharModal('modal-agendamento')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
      </div>
    </form>
  </div>
</div>

<script>
function abrirNovoAgendamento(){
  document.getElementById('modal-ag-title').textContent = 'Novo Agendamento';
  document.getElementById('ag-id').value = '';
  document.getElementById('ag-cliente').value = '';
  document.getElementById('ag-servico').value = '';
  document.getElementById('ag-funcionaria').value = '';
  document.getElementById('ag-data').value = '<?= hoje() ?>';
  document.getElementById('ag-hora').value = '';
  document.getElementById('ag-estado').value = 'pendente';
  document.getElementById('ag-obs').value = '';
  abrirModal('modal-agendamento');
}
function abrirEditarAgendamento(a){
  document.getElementById('modal-ag-title').textContent = 'Editar Agendamento';
  document.getElementById('ag-id').value = a.id;
  document.getElementById('ag-cliente').value = a.id_cliente;
  document.getElementById('ag-servico').value = a.id_servico;
  document.getElementById('ag-funcionaria').value = a.id_funcionaria || '';
  document.getElementById('ag-data').value = a.data;
  document.getElementById('ag-hora').value = a.hora.substring(0,5);
  document.getElementById('ag-estado').value = a.estado;
  document.getElementById('ag-obs').value = a.observacoes || '';
  abrirModal('modal-agendamento');
}
function lembreteWA(tel, nome, servico, data, hora){
  const salao = <?= json_encode($nomeSalao) ?>;
  const msg = `Olá ${nome}! 🌸\n\nEste é um lembrete do *${salao}*.\n\nTem um agendamento marcado:\n📋 Serviço: ${servico}\n📅 Data: ${data}\n⏰ Hora: ${hora}\n\nFicamos à sua espera! ✿`;
  abrirWhatsApp(tel, msg);
}
</script>

<?php require 'includes/footer.php'; ?>
