<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $acao = $_POST['acao'] ?? '';

    if($acao === 'salvar'){
        $descricao = trim($_POST['descricao']);
        $tipo = $_POST['tipo'];
        $categoria = trim($_POST['categoria']);
        $valor = (float)$_POST['valor'];
        $data = $_POST['data'];

        if($descricao === '' || $valor <= 0){
            setFlash('Preencha a descrição e um valor válido.','error');
            redirecionar('financeiro.php');
        }

        $stmt = $pdo->prepare("INSERT INTO financeiro (descricao,tipo,categoria,valor,data) VALUES (?,?,?,?,?)");
        $stmt->execute([$descricao,$tipo,$categoria,$valor,$data]);
        setFlash('Transacção registada!');
        redirecionar('financeiro.php');
    }

    if($acao === 'apagar'){
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM financeiro WHERE id=?");
        $stmt->execute([$id]);
        setFlash('Transacção removida.','warn');
        redirecionar('financeiro.php');
    }
}

$mesFiltro = $_GET['mes'] ?? date('Y-m');
$stmt = $pdo->prepare("SELECT * FROM financeiro WHERE DATE_FORMAT(data,'%Y-%m') = ? ORDER BY data DESC, id DESC");
$stmt->execute([$mesFiltro]);
$transacoes = $stmt->fetchAll();

$totalReceitas = 0; $totalDespesas = 0;
foreach($transacoes as $t){
    if($t['tipo']==='receita') $totalReceitas += $t['valor'];
    else $totalDespesas += $t['valor'];
}
$saldo = $totalReceitas - $totalDespesas;

$paginaAtiva = 'financeiro';
$tituloPagina = 'Financeiro';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Financeiro</div><div class="section-sub">Receitas e despesas do salão</div></div>
  <button class="btn btn-primary" onclick="abrirModal('modal-fin')">+ Nova Transacção</button>
</div>

<form method="GET" style="margin-bottom:14px;">
  <input type="month" name="mes" value="<?= h($mesFiltro) ?>" onchange="this.form.submit()">
</form>

<div class="rel-cards" style="margin-bottom:18px;">
  <div class="stat-card"><div class="stat-label">Receitas</div><div class="stat-value" style="font-size:16px;color:var(--green);"><?= fmtKz($totalReceitas) ?></div><div class="stat-icon">↑</div></div>
  <div class="stat-card"><div class="stat-label">Despesas</div><div class="stat-value" style="font-size:16px;color:var(--red);"><?= fmtKz($totalDespesas) ?></div><div class="stat-icon">↓</div></div>
  <div class="stat-card"><div class="stat-label">Saldo</div><div class="stat-value" style="font-size:16px;"><?= fmtKz($saldo) ?></div><div class="stat-icon">◎</div></div>
</div>

<div class="table-wrap">
  <table>
    <thead><tr><th>Data</th><th>Descrição</th><th>Categoria</th><th>Tipo</th><th>Valor</th><th></th></tr></thead>
    <tbody>
      <?php if(!$transacoes): ?>
        <tr><td colspan="6"><div class="empty"><div class="empty-icon">◎</div><div class="empty-text">Nenhuma transacção neste mês</div></div></td></tr>
      <?php else: foreach($transacoes as $t): ?>
        <tr>
          <td><?= fmtDataBR($t['data']) ?></td>
          <td class="td-main"><?= h($t['descricao']) ?></td>
          <td><?= ucfirst($t['categoria']) ?></td>
          <td><span class="badge <?= $t['tipo']==='receita'?'badge-green':'badge-red' ?>"><?= ucfirst($t['tipo']) ?></span></td>
          <td style="color:<?= $t['tipo']==='receita'?'var(--green)':'var(--red)' ?>;font-weight:600;"><?= ($t['tipo']==='receita'?'+':'-') . ' ' . fmtKz($t['valor']) ?></td>
          <td>
            <form method="POST" onsubmit="return confirm('Remover esta transacção?');">
              <input type="hidden" name="acao" value="apagar">
              <input type="hidden" name="id" value="<?= $t['id'] ?>">
              <button class="action-btn del" type="submit">🗑</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<div class="modal-overlay" id="modal-fin">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">Nova Transacção</div>
      <button class="modal-close" onclick="fecharModal('modal-fin')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="acao" value="salvar">
        <div class="form-group"><label>Descrição <span class="req">*</span></label><input type="text" name="descricao" required></div>
        <div class="form-row">
          <div class="form-group">
            <label>Tipo</label>
            <select name="tipo">
              <option value="receita">Receita</option>
              <option value="despesa">Despesa</option>
            </select>
          </div>
          <div class="form-group">
            <label>Categoria</label>
            <select name="categoria">
              <option value="servico">Serviço</option>
              <option value="produto">Produto</option>
              <option value="salario">Salário</option>
              <option value="renda">Renda</option>
              <option value="outro">Outro</option>
            </select>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Valor (Kz) <span class="req">*</span></label><input type="number" name="valor" min="0" required></div>
          <div class="form-group"><label>Data</label><input type="date" name="data" value="<?= hoje() ?>"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="fecharModal('modal-fin')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Guardar Transacção</button>
      </div>
    </form>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
