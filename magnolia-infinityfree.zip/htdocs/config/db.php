<?php
/**
 * config/db.php
 * Ligação à base de dados (PDO) — Magnólia Beauty Salon
 * -----------------------------------------------------------------
 * ⚠️ PREENCHE OS 4 VALORES ABAIXO com os dados da tua base de dados
 * no InfinityFree (painel → "Bases de Dados MySQL") ou no XAMPP.
 *
 * No InfinityFree, o HOST normalmente é algo como "sql312.infinityfree.com"
 * (repara no topo do phpMyAdmin, onde diz "Servidor: sql312...").
 * O NOME DA BASE DE DADOS é o que aparece no phpMyAdmin, ex:
 * "if0_42414436_lauraprojeto".
 * O UTILIZADOR normalmente é o mesmo nome da base de dados.
 * A PASSWORD é a que definiste quando criaste a base de dados MySQL
 * no painel do InfinityFree (NÃO é a password da tua conta InfinityFree).
 *
 * No XAMPP (localhost), os valores por omissão costumam ser:
 *   HOST: localhost | NOME: magnolia_beauty_salon | USER: root | PASS: (vazio)
 * -----------------------------------------------------------------
 */

$DB_HOST = 'sql312.infinityfree.com';        // <-- confirma no phpMyAdmin
$DB_NAME = 'if0_42414436_lauraprojeto';      // <-- nome da tua base de dados
$DB_USER = 'if0_42414436';                   // <-- normalmente igual ao nome da BD
$DB_PASS = 'A_TUA_PASSWORD_AQUI';            // <-- password que definiste no painel MySQL

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die('Erro de ligação à base de dados: ' . $e->getMessage());
}
