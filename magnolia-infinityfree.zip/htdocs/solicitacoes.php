<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirLogin();

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $acao = $_POST['acao'] ?? '';
    $id = (int)($_POST['id'] ?? 0);

    $stmt = $pdo->prepare("SELECT * FROM solicitacoes WHERE id=?");
    $stmt->execute([$id]);
    $sol = $stmt->fetch();

    if(!$sol){ setFlash('Solicitação não encontrada.','error'); redirecionar('solicitacoes.php'); }

    if($acao === 'confirmar'){
        $telLimpo = preg_replace('/\s+/', '', $sol['telefone']);
        $stmtCl = $pdo->prepare("SELECT id FROM clientes WHERE REPLACE(telefone,' ','') = ?");
        $stmtCl->execute([$telLimpo]);
        $cliente = $stmtCl->fetch();

        if($cliente){
            $idCliente = $cliente['id'];
        } else {
            $stmtNovo = $pdo->prepare("INSERT INTO clientes (nome, telefone, observacoes) VALUES (?,?,?)");
            $stmtNovo->execute([$sol['nome'], $sol['telefone'], 'Cliente registada automaticamente via pedido online.']);
            $idCliente = $pdo->lastInsertId();
        }

        $stmtServ = $pdo->prepare("SELECT preco FROM servicos WHERE id=?");
        $stmtServ->execute([$sol['id_servico']]);
        $valor = $stmtServ->fetch()['preco'] ?? 0;

        $stmtAg = $pdo->prepare("INSERT INTO agendamentos (id_cliente,id_servico,data,hora,estado,valor,observacoes) VALUES (?,?,?,?,?,?,?)");
        $stmtAg->execute([$idCliente, $sol['id_servico'], $sol['data'], $sol['hora'], 'confirmado', $valor, $sol['observacoes'] ?: 'Agendamento confirmado a partir de pedido online.']);
        $idAgendamento = $pdo->lastInsertId();

        $stmtUp = $pdo->prepare("UPDATE solicitacoes SET estado='confirmado', id_agendamento=? WHERE id=?");
        $stmtUp->execute([$idAgendamento, $id]);

        setFlash('Solicitação confirmada! Agendamento criado para ' . $sol['nome'] . '.');
        redirecionar('solicitacoes.php?wa=confirmado&sol_id=' . $id);
    }

    if($acao === 'recusar'){
        $stmt = $pdo->prepare("UPDATE solicitacoes SET estado='recusado' WHERE id=?");
        $stmt->execute([$id]);
        setFlash('Pedido recusado.','warn');
        redirecionar('solicitacoes.php?wa=recusado&sol_id=' . $id);
    }

    if($acao === 'reagendar'){
        $novaData = $_POST['nova_data'];
        $novaHora = $_POST['nova_hora'];
        $stmt = $pdo->prepare("UPDATE solicitacoes SET data=?, hora=?, estado='reagendado' WHERE id=?");
        $stmt->execute([$novaData, $novaHora, $id]);
        setFlash('Novo horário proposto! Confirme após o acordo com a cliente.');
        redirecionar('solicitacoes.php?wa=reagendado&sol_id=' . $id);
    }
}

// Dados para disparar o WhatsApp após um redirect (evita reenvio ao recarregar a página)
$waTipo = $_GET['wa'] ?? null;
$waSolId = (int)($_GET['sol_id'] ?? 0);
$waDados = null;
if($waTipo && $waSolId){
    $stmt = $pdo->prepare("
        SELECT sol.nome, sol.telefone, sol.data, sol.hora, s.nome AS nome_servico
        FROM solicitacoes sol JOIN servicos s ON s.id = sol.id_servico
        WHERE sol.id = ?
    ");
    $stmt->execute([$waSolId]);
    $waDados = $stmt->fetch();
}

$filtroEstado = $_GET['estado'] ?? '';
$sql = "SELECT sol.*, s.nome AS nome_servico
        FROM solicitacoes sol JOIN servicos s ON s.id = sol.id_servico";
$params = [];
if($filtroEstado){ $sql .= " WHERE sol.estado = ?"; $params[] = $filtroEstado; }
$sql .= " ORDER BY sol.criado_em DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$solicitacoes = $stmt->fetchAll();

$nomeSalao = getConfig($pdo, 'nome_salao', 'Magnólia Beauty Salon');
$waNumero = '244' . getConfig($pdo, 'wa_numero', '958391756');

$paginaAtiva = 'solicitacoes';
$tituloPagina = 'Solicitações';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Solicitações de Agendamento</div><div class="section-sub">Pedidos enviados pelas clientes através do link público</div></div>
</div>

<form method="GET" class="filters" style="margin-bottom:14px;">
  <select name="estado" onchange="this.form.submit()">
    <option value="">Todos os estados</option>
    <option value="pendente" <?= $filtroEstado==='pendente'?'selected':'' ?>>Pendente</option>
    <option value="confirmado" <?= $filtroEstado==='confirmado'?'selected':'' ?>>Confirmado</option>
    <option value="reagendado" <?= $filtroEstado==='reagendado'?'selected':'' ?>>Reagendado</option>
    <option value="recusado" <?= $filtroEstado==='recusado'?'selected':'' ?>>Recusado</option>
  </select>
</form>

<?php if(!$solicitacoes): ?>
  <div class="empty"><div class="empty-icon">🔔</div><div class="empty-text">Nenhuma solicitação encontrada</div></div>
<?php else: foreach($solicitacoes as $s): ?>
  <div class="sol-card">
    <div class="sol-card-top">
      <div>
        <div class="sol-name"><?= h($s['nome']) ?></div>
        <div class="sol-meta">
          📞 <?= h($s['telefone']) ?> &nbsp;·&nbsp; <?= h($s['nome_servico']) ?><br>
          📅 <?= fmtDataBR($s['data']) ?> às <?= substr($s['hora'],0,5) ?>
        </div>
      </div>
      <?= badgeEstadoSolicitacao($s['estado']) ?>
    </div>
    <?php if($s['observacoes']): ?><div class="sol-obs">💬 <?= h($s['observacoes']) ?></div><?php endif; ?>
    <?php if(in_array($s['estado'], ['pendente','reagendado'])): ?>
    <div class="sol-actions">
      <form method="POST" style="display:inline;">
        <input type="hidden" name="acao" value="confirmar">
        <input type="hidden" name="id" value="<?= $s['id'] ?>">
        <button class="btn btn-primary btn-sm" type="submit">✓ Confirmar</button>
      </form>
      <button class="btn btn-ghost btn-sm" onclick="abrirReagendar(<?= $s['id'] ?>,'<?= h($s['data']) ?>','<?= substr($s['hora'],0,5) ?>')">🔄 Reagendar</button>
      <form method="POST" style="display:inline;" onsubmit="return confirm('Recusar este pedido?');">
        <input type="hidden" name="acao" value="recusar">
        <input type="hidden" name="id" value="<?= $s['id'] ?>">
        <button class="btn btn-danger btn-sm" type="submit">✕ Recusar</button>
      </form>
    </div>
    <?php endif; ?>
  </div>
<?php endforeach; endif; ?>

<div class="modal-overlay" id="modal-reagendar">
  <div class="modal" style="width:380px;">
    <div class="modal-header">
      <div class="modal-title">🔄 Propor Novo Horário</div>
      <button class="modal-close" onclick="fecharModal('modal-reagendar')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="acao" value="reagendar">
        <input type="hidden" name="id" id="reag-id">
        <div style="font-size:12px;color:var(--text3);margin-bottom:14px;">Escolha a nova data/hora a propor. O pedido volta a ficar pendente até confirmação.</div>
        <div class="form-row">
          <div class="form-group"><label>Nova data <span class="req">*</span></label><input type="date" name="nova_data" id="reag-data" required></div>
          <div class="form-group"><label>Nova hora <span class="req">*</span></label><input type="time" name="nova_hora" id="reag-hora" required></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="fecharModal('modal-reagendar')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Guardar e Notificar</button>
      </div>
    </form>
  </div>
</div>

<script>
function abrirReagendar(id, data, hora){
  document.getElementById('reag-id').value = id;
  document.getElementById('reag-data').value = data;
  document.getElementById('reag-hora').value = hora;
  abrirModal('modal-reagendar');
}

<?php if($waDados): ?>
window.addEventListener('DOMContentLoaded', function(){
  const salao = <?= json_encode($nomeSalao) ?>;
  const waNumero = <?= json_encode($waNumero) ?>;
  const nome = <?= json_encode($waDados['nome']) ?>;
  const servico = <?= json_encode($waDados['nome_servico']) ?>;
  const data = <?= json_encode(fmtDataBR($waDados['data'])) ?>;
  const hora = <?= json_encode(substr($waDados['hora'],0,5)) ?>;
  const tel = <?= json_encode(formatarTelWhatsApp($waDados['telefone'])) ?>;
  let msg = '';
  <?php if($waTipo === 'confirmado'): ?>
    msg = `Olá ${nome}! 👋\n\n✅ O seu pedido de agendamento no *${salao}* foi *confirmado*.\n\n📋 *Detalhes:*\n• Serviço: ${servico}\n• Data: ${data}\n• Hora: ${hora}\n\nContacto do salão: +${waNumero}. Até breve! 🌸`;
  <?php elseif($waTipo === 'recusado'): ?>
    msg = `Olá ${nome}. 👋\n\nInfelizmente não foi possível confirmar o seu pedido de agendamento (${servico}, ${data} às ${hora}) no *${salao}*.\n\nPor favor contacte-nos pelo +${waNumero} para encontrarmos um novo horário. Obrigada pela compreensão! 🌸`;
  <?php else: ?>
    msg = `Olá ${nome}! 👋\n\n🔄 Propomos um novo horário para o seu agendamento de *${servico}* no *${salao}*:\n\n📅 Nova data: ${data}\n⏰ Nova hora: ${hora}\n\nPor favor confirme respondendo a esta mensagem. Contacto: +${waNumero}. Obrigada! 🌸`;
  <?php endif; ?>
  abrirWhatsApp(tel, msg);
});
<?php endif; ?>
</script>

<?php require 'includes/footer.php'; ?>
