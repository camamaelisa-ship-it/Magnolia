<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirLogin();

if(!isset($_SESSION['carrinho'])){
    $_SESSION['carrinho'] = ['id_cliente' => null, 'itens' => []];
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $acao = $_POST['acao'] ?? '';

    if($acao === 'definir_cliente'){
        $_SESSION['carrinho']['id_cliente'] = $_POST['id_cliente'] !== '' ? (int)$_POST['id_cliente'] : null;
        redirecionar('carrinho.php');
    }

    if($acao === 'adicionar'){
        $selecao = $_POST['item_select'] ?? '';
        $qtd = max(1, (int)($_POST['quantidade'] ?? 1));
        [$tipo, $idRef] = array_pad(explode(':', $selecao), 2, null);
        $idRef = (int)$idRef;

        if($tipo === 'servico'){
            $stmt = $pdo->prepare("SELECT * FROM servicos WHERE id=?");
            $stmt->execute([$idRef]);
            $item = $stmt->fetch();
            if(!$item){ setFlash('Serviço não encontrado.','error'); redirecionar('carrinho.php'); }
            $encontrado = false;
            foreach($_SESSION['carrinho']['itens'] as &$it){
                if($it['tipo']==='servico' && $it['id_referencia']===$idRef){ $it['quantidade'] += $qtd; $encontrado = true; break; }
            }
            unset($it);
            if(!$encontrado){
                $_SESSION['carrinho']['itens'][] = ['tipo'=>'servico','id_referencia'=>$idRef,'nome'=>$item['nome'],'preco'=>(float)$item['preco'],'quantidade'=>$qtd];
            }
        } elseif($tipo === 'produto'){
            $stmt = $pdo->prepare("SELECT * FROM stock WHERE id=?");
            $stmt->execute([$idRef]);
            $item = $stmt->fetch();
            if(!$item){ setFlash('Produto não encontrado.','error'); redirecionar('carrinho.php'); }
            $jaNoCarrinho = 0;
            foreach($_SESSION['carrinho']['itens'] as $it){
                if($it['tipo']==='produto' && $it['id_referencia']===$idRef) $jaNoCarrinho += $it['quantidade'];
            }
            if($item['quantidade'] < $jaNoCarrinho + $qtd){
                setFlash("Estoque insuficiente. Disponível: {$item['quantidade']} {$item['unidade']}.",'error');
                redirecionar('carrinho.php');
            }
            $encontrado = false;
            foreach($_SESSION['carrinho']['itens'] as &$it){
                if($it['tipo']==='produto' && $it['id_referencia']===$idRef){ $it['quantidade'] += $qtd; $encontrado = true; break; }
            }
            unset($it);
            if(!$encontrado){
                $_SESSION['carrinho']['itens'][] = ['tipo'=>'produto','id_referencia'=>$idRef,'nome'=>$item['nome'],'preco'=>(float)$item['preco'],'quantidade'=>$qtd];
            }
        } else {
            setFlash('Seleccione um item válido.','error');
        }
        redirecionar('carrinho.php');
    }

    if($acao === 'remover'){
        $idx = (int)$_POST['idx'];
        if(isset($_SESSION['carrinho']['itens'][$idx])){
            array_splice($_SESSION['carrinho']['itens'], $idx, 1);
        }
        redirecionar('carrinho.php');
    }

    if($acao === 'limpar'){
        $_SESSION['carrinho'] = ['id_cliente' => null, 'itens' => []];
        setFlash('Carrinho esvaziado.','warn');
        redirecionar('carrinho.php');
    }

    if($acao === 'gerar_fatura'){
        $carrinho = $_SESSION['carrinho'];
        if(!$carrinho['id_cliente']){ setFlash('Seleccione a cliente antes de gerar a fatura.','error'); redirecionar('carrinho.php'); }
        if(!$carrinho['itens']){ setFlash('O carrinho está vazio.','error'); redirecionar('carrinho.php'); }

        try {
            $pdo->beginTransaction();

            // Verificação final de estoque (RF005)
            foreach($carrinho['itens'] as $it){
                if($it['tipo'] === 'produto'){
                    $stmt = $pdo->prepare("SELECT quantidade FROM stock WHERE id=? FOR UPDATE");
                    $stmt->execute([$it['id_referencia']]);
                    $row = $stmt->fetch();
                    if(!$row || $row['quantidade'] < $it['quantidade']){
                        throw new Exception("Estoque insuficiente para \"{$it['nome']}\".");
                    }
                }
            }

            $total = array_reduce($carrinho['itens'], fn($s,$it)=>$s + $it['preco']*$it['quantidade'], 0);
            $stmtCl = $pdo->prepare("SELECT nome FROM clientes WHERE id=?");
            $stmtCl->execute([$carrinho['id_cliente']]);
            $nomeCliente = $stmtCl->fetch()['nome'] ?? null;

            $stmtFat = $pdo->prepare("INSERT INTO faturas (id_cliente, nome_cliente, total, estado, emitido_por) VALUES (?,?,?,?,?)");
            $stmtFat->execute([$carrinho['id_cliente'], $nomeCliente, $total, 'emitida', $_SESSION['nome']]);
            $idFatura = $pdo->lastInsertId();

            $stmtItem = $pdo->prepare("INSERT INTO fatura_itens (id_fatura, tipo, id_referencia, nome, preco, quantidade) VALUES (?,?,?,?,?,?)");
            foreach($carrinho['itens'] as $it){
                $stmtItem->execute([$idFatura, $it['tipo'], $it['id_referencia'], $it['nome'], $it['preco'], $it['quantidade']]);
                if($it['tipo'] === 'produto'){
                    $stmtBaixa = $pdo->prepare("UPDATE stock SET quantidade = quantidade - ? WHERE id = ?");
                    $stmtBaixa->execute([$it['quantidade'], $it['id_referencia']]);
                }
            }

            $stmtFin = $pdo->prepare("INSERT INTO financeiro (descricao, tipo, categoria, valor, data) VALUES (?,?,?,?,?)");
            $stmtFin->execute(["Fatura #" . str_pad($idFatura, 6, '0', STR_PAD_LEFT), 'receita', 'servico', $total, hoje()]);

            $pdo->commit();
            $_SESSION['carrinho'] = ['id_cliente' => null, 'itens' => []];
            setFlash('Fatura gerada com sucesso!');
            redirecionar('faturas.php?ver=' . $idFatura);
        } catch(Exception $e){
            $pdo->rollBack();
            setFlash('Erro ao gerar fatura: ' . $e->getMessage(), 'error');
            redirecionar('carrinho.php');
        }
    }
}

$clientes = $pdo->query("SELECT id, nome FROM clientes ORDER BY nome ASC")->fetchAll();
$servicos = $pdo->query("SELECT id, nome, preco FROM servicos ORDER BY nome ASC")->fetchAll();
$produtos = $pdo->query("SELECT id, nome, preco, quantidade, unidade FROM stock ORDER BY nome ASC")->fetchAll();

$carrinho = $_SESSION['carrinho'];
$totalCarrinho = array_reduce($carrinho['itens'], fn($s,$it)=>$s + $it['preco']*$it['quantidade'], 0);

$paginaAtiva = 'carrinho';
$tituloPagina = 'Carrinho';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Carrinho</div><div class="section-sub">Adicione serviços e produtos para gerar uma fatura</div></div>
</div>

<form method="POST" style="margin-bottom:14px;">
  <input type="hidden" name="acao" value="definir_cliente">
  <div class="form-group">
    <label>Cliente <span class="req">*</span></label>
    <select name="id_cliente" onchange="this.form.submit()">
      <option value="">-- Seleccionar cliente --</option>
      <?php foreach($clientes as $c): ?>
        <option value="<?= $c['id'] ?>" <?= $carrinho['id_cliente']==$c['id']?'selected':'' ?>><?= h($c['nome']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
</form>

<form method="POST" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:16px;align-items:flex-end;">
  <input type="hidden" name="acao" value="adicionar">
  <div class="form-group" style="flex:2;min-width:220px;margin-bottom:0;">
    <label>Item</label>
    <select name="item_select">
      <optgroup label="Serviços">
        <?php foreach($servicos as $s): ?>
          <option value="servico:<?= $s['id'] ?>">✦ <?= h($s['nome']) ?> (<?= fmtKz($s['preco']) ?>)</option>
        <?php endforeach; ?>
      </optgroup>
      <optgroup label="Produtos">
        <?php foreach($produtos as $p): ?>
          <option value="produto:<?= $p['id'] ?>">📦 <?= h($p['nome']) ?> (<?= fmtKz($p['preco']) ?>) — stock: <?= $p['quantidade'] ?> <?= h($p['unidade']) ?></option>
        <?php endforeach; ?>
      </optgroup>
    </select>
  </div>
  <div class="form-group" style="width:90px;margin-bottom:0;">
    <label>Qtd</label>
    <input type="number" name="quantidade" value="1" min="1">
  </div>
  <button class="btn btn-primary" type="submit">+ Adicionar</button>
</form>

<div class="table-wrap">
  <table>
    <thead><tr><th>Item</th><th>Tipo</th><th>Preço</th><th>Qtd</th><th>Subtotal</th><th></th></tr></thead>
    <tbody>
      <?php if(!$carrinho['itens']): ?>
        <tr><td colspan="6"><div class="empty"><div class="empty-icon">🛒</div><div class="empty-text">Carrinho vazio</div></div></td></tr>
      <?php else: foreach($carrinho['itens'] as $idx => $it): ?>
        <tr>
          <td class="td-main"><?= h($it['nome']) ?></td>
          <td><?= $it['tipo']==='servico'?'Serviço':'Produto' ?></td>
          <td><?= fmtKz($it['preco']) ?></td>
          <td><?= $it['quantidade'] ?></td>
          <td style="color:var(--accent2);font-weight:600;"><?= fmtKz($it['preco']*$it['quantidade']) ?></td>
          <td>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="acao" value="remover">
              <input type="hidden" name="idx" value="<?= $idx ?>">
              <button class="action-btn del" type="submit">🗑</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<div style="display:flex;justify-content:space-between;align-items:center;margin-top:16px;">
  <div style="font-size:16px;font-weight:700;">Total: <span style="color:var(--accent2);"><?= fmtKz($totalCarrinho) ?></span></div>
  <div style="display:flex;gap:8px;">
    <form method="POST" onsubmit="return confirm('Esvaziar o carrinho?');">
      <input type="hidden" name="acao" value="limpar">
      <button class="btn btn-ghost" type="submit">Esvaziar</button>
    </form>
    <form method="POST">
      <input type="hidden" name="acao" value="gerar_fatura">
      <button class="btn btn-primary" type="submit">Gerar Fatura</button>
    </form>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
