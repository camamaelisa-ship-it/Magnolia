  </div>
</div>

<div id="toast-container" style="position:fixed;bottom:20px;right:20px;z-index:2000;display:flex;flex-direction:column;gap:8px;"></div>

<script>
function toggleSidebar(){
  document.getElementById('sidebar').classList.toggle('mobile-open');
  document.getElementById('sidebar-backdrop').classList.toggle('show');
}

function toast(msg, tipo){
  tipo = tipo || 'success';
  const cores = {success:'#2a8a55', error:'#b84040', warn:'#a07820'};
  const el = document.createElement('div');
  el.textContent = msg;
  el.style.cssText = `background:${cores[tipo]||cores.success};color:#fff;padding:10px 16px;border-radius:8px;font-size:13px;font-family:'DM Sans',sans-serif;box-shadow:0 4px 12px rgba(0,0,0,.3);animation:fadein .2s ease;`;
  document.getElementById('toast-container').appendChild(el);
  setTimeout(()=>el.remove(), 3500);
}

<?php if(!empty($_SESSION['flash_msg'])): ?>
window.addEventListener('DOMContentLoaded', ()=> toast(<?= json_encode($_SESSION['flash_msg']) ?>, <?= json_encode($_SESSION['flash_tipo'] ?? 'success') ?>));
<?php unset($_SESSION['flash_msg'], $_SESSION['flash_tipo']); endif; ?>

function abrirModal(id){ document.getElementById(id).classList.add('open'); }
function fecharModal(id){ document.getElementById(id).classList.remove('open'); }

// Abre o WhatsApp: no Android usa intent:// (abre a app instalada directamente),
// nos outros dispositivos usa wa.me (funciona bem no Chrome/Safari/desktop).
function abrirWhatsApp(tel, msg){
  const texto = encodeURIComponent(msg);
  const linkWeb = `https://wa.me/${tel}?text=${texto}`;
  const isAndroid = /Android/i.test(navigator.userAgent);
  if(isAndroid){
    const fallback = encodeURIComponent(linkWeb);
    window.location.href = `intent://send?phone=${tel}&text=${texto}#Intent;scheme=whatsapp;package=com.whatsapp;S.browser_fallback_url=${fallback};end`;
    return;
  }
  const a = document.createElement('a');
  a.href = linkWeb; a.rel = 'noopener'; a.style.display = 'none';
  document.body.appendChild(a); a.click();
  setTimeout(()=>a.remove(), 500);
}
</script>
</body>
</html>
