<?php
/**
 * includes/header.php
 * Espera que $paginaAtiva e $tituloPagina estejam definidos antes do include.
 * Requer includes/auth.php e includes/functions.php já carregados.
 */
exigirLogin();

$nomeSalao = getConfig($pdo, 'nome_salao', 'Magnólia Beauty Salon');
$souAdmin = tipoLogado() === 'admin';

// Contagem de solicitações pendentes (para o badge da barra lateral)
$stmtSol = $pdo->query("SELECT COUNT(*) AS n FROM solicitacoes WHERE estado = 'pendente'");
$pendentes = (int)$stmtSol->fetch()['n'];

$navItems = [
    ['id'=>'index',          'icon'=>'⊞', 'label'=>'Dashboard',      'href'=>'index.php',          'adminOnly'=>false],
    ['id'=>'agendamentos',   'icon'=>'◷', 'label'=>'Agendamentos',   'href'=>'agendamentos.php',   'adminOnly'=>false],
    ['id'=>'solicitacoes',   'icon'=>'🔔','label'=>'Solicitações',   'href'=>'solicitacoes.php',   'adminOnly'=>false, 'badge'=>$pendentes],
    ['id'=>'clientes',       'icon'=>'◈', 'label'=>'Clientes',       'href'=>'clientes.php',       'adminOnly'=>false],
    ['id'=>'servicos',       'icon'=>'✦', 'label'=>'Serviços',       'href'=>'servicos.php',       'adminOnly'=>false],
    ['id'=>'funcionarios',   'icon'=>'◉', 'label'=>'Funcionários',   'href'=>'funcionarios.php',   'adminOnly'=>true],
    ['id'=>'stock',          'icon'=>'📦','label'=>'Stock',          'href'=>'stock.php',          'adminOnly'=>true],
    ['id'=>'carrinho',       'icon'=>'🛒','label'=>'Carrinho',       'href'=>'carrinho.php',       'adminOnly'=>false],
    ['id'=>'faturas',        'icon'=>'🧾','label'=>'Faturas',        'href'=>'faturas.php',        'adminOnly'=>false],
    ['id'=>'financeiro',     'icon'=>'◎', 'label'=>'Financeiro',     'href'=>'financeiro.php',     'adminOnly'=>true],
    ['id'=>'relatorios',     'icon'=>'📊','label'=>'Relatórios',     'href'=>'relatorios.php',     'adminOnly'=>true],
    ['id'=>'administrador',  'icon'=>'⚙', 'label'=>'Administrador',  'href'=>'administrador.php',  'adminOnly'=>true],
];
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($tituloPagina) ?> — <?= h($nomeSalao) ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body>

<div class="sidebar-backdrop" id="sidebar-backdrop" onclick="toggleSidebar()"></div>
<aside id="sidebar">
  <div class="sidebar-logo" style="display:flex;align-items:center;gap:10px;padding:16px 14px;border-bottom:1px solid var(--border);">
    <div style="width:34px;height:34px;background:var(--accent-dark);border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:17px;">✿</div>
    <div>
      <div class="logo-name" style="font-weight:700;font-size:14px;"><?= h($nomeSalao) ?></div>
      <div style="font-size:11px;color:var(--text3);"><?= $souAdmin ? 'Administradora' : 'Funcionária' ?></div>
    </div>
  </div>
  <nav style="padding:10px;flex:1;overflow-y:auto;">
    <?php foreach($navItems as $item):
        if($item['adminOnly'] && !$souAdmin) continue;
        $ativo = $paginaAtiva === $item['id'] ? 'active' : '';
    ?>
    <a href="<?= $item['href'] ?>" class="nav-item <?= $ativo ?>" style="text-decoration:none;">
      <span class="icon"><?= $item['icon'] ?></span> <?= h($item['label']) ?>
      <?php if(!empty($item['badge'])): ?>
        <span class="nav-badge"><?= (int)$item['badge'] ?></span>
      <?php endif; ?>
    </a>
    <?php endforeach; ?>
  </nav>
  <div class="sidebar-footer">
    <div style="font-size:12px;color:var(--text2);margin-bottom:8px;">👤 <?= h($_SESSION['nome']) ?></div>
    <a href="logout.php" class="btn btn-ghost btn-sm" style="width:100%;text-align:center;display:block;text-decoration:none;">Sair</a>
  </div>
</aside>

<div id="main">
  <div class="topbar">
    <div style="display:flex;align-items:center;gap:12px;">
      <button class="mobile-menu-btn" onclick="toggleSidebar()">☰</button>
      <div>
        <div class="topbar-title"><?= h($tituloPagina) ?></div>
        <div class="topbar-date"><?= date('d/m/Y') ?></div>
      </div>
    </div>
    <div class="topbar-right" id="topbar-right"></div>
  </div>
  <div class="page-content" style="padding:20px;">
