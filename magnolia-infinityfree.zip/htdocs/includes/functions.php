<?php
/**
 * includes/functions.php
 * Funções auxiliares partilhadas por todo o sistema.
 */

function fmtKz($v){
    return number_format((float)$v, 0, ',', '.') . ' Kz';
}

function fmtDataBR($d){
    if(!$d) return '—';
    $partes = explode('-', $d);
    if(count($partes) !== 3) return $d;
    return $partes[2] . '/' . $partes[1] . '/' . $partes[0];
}

function fmtDataHoraBR($dt){
    if(!$dt) return '—';
    $ts = strtotime($dt);
    return date('d/m/Y H:i', $ts);
}

function hoje(){
    return date('Y-m-d');
}

/**
 * Normaliza um telefone angolano para o formato internacional usado
 * pelo WhatsApp (2449XXXXXXXX), sem espaços.
 */
function formatarTelWhatsApp($raw){
    $tel = preg_replace('/\D/', '', $raw);
    if(strpos($tel, '0') === 0){
        $tel = '244' . substr($tel, 1);
    }
    if(strpos($tel, '244') !== 0){
        $tel = '244' . $tel;
    }
    return $tel;
}

/**
 * Constrói o link wa.me (usado como alternativa/fallback universal).
 */
function linkWhatsApp($telefone, $mensagem){
    $tel = formatarTelWhatsApp($telefone);
    return 'https://wa.me/' . $tel . '?text=' . rawurlencode($mensagem);
}

function badgeEstadoAgendamento($estado){
    $map = [
        'pendente'   => ['badge-yellow', 'pendente'],
        'confirmado' => ['badge-green',  'confirmado'],
        'concluido'  => ['badge-blue',   'concluído'],
        'cancelado'  => ['badge-red',    'cancelado'],
    ];
    [$classe, $label] = $map[$estado] ?? ['badge-gray', $estado];
    return "<span class=\"badge {$classe}\">{$label}</span>";
}

function badgeEstadoSolicitacao($estado){
    $map = [
        'pendente'   => ['badge-yellow', 'Pendente'],
        'confirmado' => ['badge-green',  'Confirmado'],
        'reagendado' => ['badge-blue',   'Reagendado'],
        'recusado'   => ['badge-red',    'Recusado'],
    ];
    [$classe, $label] = $map[$estado] ?? ['badge-gray', $estado];
    return "<span class=\"badge {$classe}\">{$label}</span>";
}

function h($str){
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function redirecionar($url){
    header('Location: ' . $url);
    exit;
}

function setFlash($msg, $tipo = 'success'){
    $_SESSION['flash_msg'] = $msg;
    $_SESSION['flash_tipo'] = $tipo;
}
