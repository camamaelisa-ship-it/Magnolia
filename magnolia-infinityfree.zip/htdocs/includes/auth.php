<?php
/**
 * includes/auth.php
 * Magnólia Beauty Salon — Autenticação por PIN
 * -----------------------------------------------------------------
 * RF014 — Encriptação de PINs (password_hash / bcrypt)
 * RF015 — Bloqueio por tentativas inválidas
 * RF001 — Controlo de acesso por perfil (admin / funcionária)
 * -----------------------------------------------------------------
 */
require_once __DIR__ . '/../config/db.php';

session_start();

const MAX_TENTATIVAS   = 3;   // nº máximo de tentativas de PIN erradas
const MINUTOS_BLOQUEIO  = 5;  // tempo de bloqueio, em minutos

/**
 * Lê um valor da tabela `configuracoes` (chave/valor).
 */
function getConfig($pdo, $chave, $default = null) {
    $stmt = $pdo->prepare("SELECT valor FROM configuracoes WHERE chave = ?");
    $stmt->execute([$chave]);
    $row = $stmt->fetch();
    return $row ? $row['valor'] : $default;
}

function setConfig($pdo, $chave, $valor) {
    $stmt = $pdo->prepare(
        "INSERT INTO configuracoes (chave, valor) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE valor = VALUES(valor)"
    );
    $stmt->execute([$chave, $valor]);
}

/**
 * Verifica se uma conta está bloqueada. Devolve minutos restantes (0 se não estiver bloqueada).
 */
function minutosBloqueioRestante($bloqueadoAte) {
    if (!$bloqueadoAte) return 0;
    $restante = strtotime($bloqueadoAte) - time();
    return $restante > 0 ? (int)ceil($restante / 60) : 0;
}

/**
 * Autentica a Administradora pelo PIN.
 * Retorna ['ok'=>bool, 'msg'=>string]
 */
function autenticarAdmin($pdo, $pin) {
    $stmt = $pdo->prepare("SELECT * FROM administradores ORDER BY id ASC LIMIT 1");
    $stmt->execute();
    $admin = $stmt->fetch();

    if (!$admin) {
        return ['ok' => false, 'msg' => 'Conta de administração não encontrada.'];
    }

    $restante = minutosBloqueioRestante($admin['bloqueado_ate']);
    if ($restante > 0) {
        return ['ok' => false, 'msg' => "Conta bloqueada. Tente novamente em {$restante} minuto(s)."];
    }

    if (password_verify($pin, $admin['pin_hash'])) {
        $stmt = $pdo->prepare("UPDATE administradores SET tentativas_invalidas = 0, bloqueado_ate = NULL WHERE id = ?");
        $stmt->execute([$admin['id']]);

        $_SESSION['tipo']      = 'admin';
        $_SESSION['id']        = $admin['id'];
        $_SESSION['nome']      = $admin['nome'];

        return ['ok' => true, 'msg' => 'Login efectuado com sucesso.'];
    }

    return registarTentativaFalhada($pdo, 'administradores', $admin['id'], $admin['tentativas_invalidas']);
}

/**
 * Autentica uma Funcionária pelo ID (seleccionada no dropdown) + PIN.
 * Se a funcionária não tiver PIN individual (pin_hash NULL), usa o PIN geral
 * guardado em configuracoes.pin_func_geral_hash.
 */
function autenticarFuncionaria($pdo, $idFuncionaria, $pin) {
    $stmt = $pdo->prepare("SELECT * FROM funcionarios WHERE id = ? AND estado = 'activa'");
    $stmt->execute([$idFuncionaria]);
    $func = $stmt->fetch();

    if (!$func) {
        return ['ok' => false, 'msg' => 'Funcionária não encontrada ou inactiva.'];
    }

    $restante = minutosBloqueioRestante($func['bloqueado_ate']);
    if ($restante > 0) {
        return ['ok' => false, 'msg' => "Conta bloqueada. Tente novamente em {$restante} minuto(s)."];
    }

    $hashParaVerificar = $func['pin_hash'] ?: getConfig($pdo, 'pin_func_geral_hash');

    if ($hashParaVerificar && password_verify($pin, $hashParaVerificar)) {
        $stmt = $pdo->prepare("UPDATE funcionarios SET tentativas_invalidas = 0, bloqueado_ate = NULL WHERE id = ?");
        $stmt->execute([$func['id']]);

        $_SESSION['tipo']      = 'funcionaria';
        $_SESSION['id']        = $func['id'];
        $_SESSION['nome']      = $func['nome'];

        return ['ok' => true, 'msg' => 'Login efectuado com sucesso.'];
    }

    return registarTentativaFalhada($pdo, 'funcionarios', $func['id'], $func['tentativas_invalidas']);
}

/**
 * RF015 — regista uma tentativa falhada e bloqueia a conta se atingir o limite.
 */
function registarTentativaFalhada($pdo, $tabela, $id, $tentativasAtuais) {
    $tentativas = $tentativasAtuais + 1;

    if ($tentativas >= MAX_TENTATIVAS) {
        $bloqueadoAte = date('Y-m-d H:i:s', strtotime('+' . MINUTOS_BLOQUEIO . ' minutes'));
        $stmt = $pdo->prepare("UPDATE `{$tabela}` SET tentativas_invalidas = ?, bloqueado_ate = ? WHERE id = ?");
        $stmt->execute([$tentativas, $bloqueadoAte, $id]);
        return ['ok' => false, 'msg' => "PIN incorrecto. Conta bloqueada durante " . MINUTOS_BLOQUEIO . " minutos após {$tentativas} tentativas erradas."];
    }

    $stmt = $pdo->prepare("UPDATE `{$tabela}` SET tentativas_invalidas = ? WHERE id = ?");
    $stmt->execute([$tentativas, $id]);
    $restantes = MAX_TENTATIVAS - $tentativas;
    return ['ok' => false, 'msg' => "PIN incorrecto. Tentativa(s) restante(s): {$restantes}."];
}

function estaLogado() {
    return isset($_SESSION['tipo']);
}

function tipoLogado() {
    return $_SESSION['tipo'] ?? null;
}

function exigirLogin() {
    if (!estaLogado()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * RF001 — restringe uma página só à administradora.
 */
function exigirAdmin() {
    exigirLogin();
    if (tipoLogado() !== 'admin') {
        http_response_code(403);
        echo "<h2 style='font-family:sans-serif;text-align:center;margin-top:60px;'>Acesso restrito à administração.</h2>";
        echo "<p style='text-align:center;'><a href='index.php'>Voltar</a></p>";
        exit;
    }
}

function fazerLogout() {
    $_SESSION = [];
    session_destroy();
    header('Location: login.php');
    exit;
}
