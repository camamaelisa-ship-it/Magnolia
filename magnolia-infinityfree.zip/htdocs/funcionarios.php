<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $acao = $_POST['acao'] ?? '';

    if($acao === 'salvar'){
        $id = (int)($_POST['id'] ?? 0);
        $nome = trim($_POST['nome']);
        $cargo = trim($_POST['cargo']);
        $telefone = trim($_POST['telefone']);
        $salario = (float)($_POST['salario'] ?? 0);
        $dataEntrada = $_POST['data_entrada'];
        $estado = $_POST['estado'];
        $novoPin = trim($_POST['novo_pin'] ?? '');

        if($nome === '' || $cargo === ''){
            setFlash('Nome e cargo são obrigatórios.','error');
            redirecionar('funcionarios.php');
        }

        if($id){
            $stmt = $pdo->prepare("UPDATE funcionarios SET nome=?, cargo=?, telefone=?, salario=?, data_entrada=?, estado=? WHERE id=?");
            $stmt->execute([$nome,$cargo,$telefone,$salario,$dataEntrada,$estado,$id]);
            $msg = 'Funcionária actualizada!';
        } else {
            $stmt = $pdo->prepare("INSERT INTO funcionarios (nome,cargo,telefone,salario,data_entrada,estado) VALUES (?,?,?,?,?,?)");
            $stmt->execute([$nome,$cargo,$telefone,$salario,$dataEntrada,$estado]);
            $id = $pdo->lastInsertId();
            $msg = 'Funcionária registada!';
        }

        // Define/actualiza o PIN individual (gera o hash automaticamente)
        if($novoPin !== ''){
            if(!preg_match('/^\d{4}$/', $novoPin)){
                setFlash('O PIN deve ter exactamente 4 dígitos.','error');
                redirecionar('funcionarios.php');
            }
            $hash = password_hash($novoPin, PASSWORD_BCRYPT);
            $stmt = $pdo->prepare("UPDATE funcionarios SET pin_hash=?, tentativas_invalidas=0, bloqueado_ate=NULL WHERE id=?");
            $stmt->execute([$hash, $id]);
            $msg .= ' PIN individual definido.';
        }

        setFlash($msg);
        redirecionar('funcionarios.php');
    }

    if($acao === 'remover_pin'){
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("UPDATE funcionarios SET pin_hash=NULL, tentativas_invalidas=0, bloqueado_ate=NULL WHERE id=?");
        $stmt->execute([$id]);
        setFlash('PIN individual removido — passa a usar o PIN geral das funcionárias.','warn');
        redirecionar('funcionarios.php');
    }

    if($acao === 'apagar'){
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM funcionarios WHERE id=?");
        $stmt->execute([$id]);
        setFlash('Funcionária removida. Os agendamentos que tinha associados ficam sem profissional atribuído.','warn');
        redirecionar('funcionarios.php');
    }
}

$funcionarios = $pdo->query("SELECT * FROM funcionarios ORDER BY nome ASC")->fetchAll();
$taxaComissao = (float)getConfig($pdo, 'taxa_comissao', 15);
$mesAtual = date('Y-m');

$paginaAtiva = 'funcionarios';
$tituloPagina = 'Funcionários';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Funcionários</div><div class="section-sub">Equipa do salão — comissão actual: <?= $taxaComissao ?>%</div></div>
  <button class="btn btn-primary" onclick="abrirNovaFuncionaria()">+ Nova Funcionária</button>
</div>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;">
  <?php if(!$funcionarios): ?>
    <div class="empty"><div class="empty-icon">◉</div><div class="empty-text">Nenhuma funcionária registada</div></div>
  <?php else: foreach($funcionarios as $f):
      $stmtTotal = $pdo->prepare("SELECT COALESCE(SUM(valor),0) v FROM agendamentos WHERE id_funcionaria=? AND estado='concluido' AND DATE_FORMAT(data,'%Y-%m')=?");
      $stmtTotal->execute([$f['id'], $mesAtual]);
      $totalMes = $stmtTotal->fetch()['v'];
      $comissao = round($totalMes * ($taxaComissao/100));
      $estadoBadgeMap = ['activa'=>'badge-green','inactiva'=>'badge-red','ferias'=>'badge-yellow'];
  ?>
    <div class="card">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;">
        <div>
          <div style="font-weight:600;font-size:14px;"><?= h($f['nome']) ?></div>
          <div style="font-size:12px;color:var(--text3);"><?= h($f['cargo']) ?></div>
        </div>
        <span class="badge <?= $estadoBadgeMap[$f['estado']] ?? 'badge-gray' ?>"><?= ucfirst($f['estado']) ?></span>
      </div>
      <div style="font-size:12px;color:var(--text3);margin-top:8px;line-height:1.7;">
        📞 <?= h($f['telefone']) ?><br>
        💰 Comissão este mês: <strong style="color:var(--accent2);"><?= fmtKz($comissao) ?></strong>
        <span style="color:var(--text3);">(sobre <?= fmtKz($totalMes) ?>)</span><br>
        🔑 PIN: <?= $f['pin_hash'] ? '<span style="color:var(--green);">individual definido</span>' : '<span style="color:var(--text3);">usa o PIN geral</span>' ?>
      </div>
      <div class="client-footer">
        <button class="btn btn-ghost btn-sm" onclick='abrirEditarFuncionaria(<?= json_encode($f) ?>)'>✎ Editar</button>
        <?php if($f['pin_hash']): ?>
        <form method="POST" style="display:inline;" onsubmit="return confirm('Remover o PIN individual? Passa a usar o PIN geral.');">
          <input type="hidden" name="acao" value="remover_pin">
          <input type="hidden" name="id" value="<?= $f['id'] ?>">
          <button class="btn btn-ghost btn-sm" type="submit">🔓 Remover PIN</button>
        </form>
        <?php endif; ?>
        <form method="POST" style="display:inline;" onsubmit="return confirm('Remover esta funcionária?');">
          <input type="hidden" name="acao" value="apagar">
          <input type="hidden" name="id" value="<?= $f['id'] ?>">
          <button class="btn btn-danger btn-sm" type="submit">🗑</button>
        </form>
      </div>
    </div>
  <?php endforeach; endif; ?>
</div>

<div class="modal-overlay" id="modal-func">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title" id="modal-fn-title">Nova Funcionária</div>
      <button class="modal-close" onclick="fecharModal('modal-func')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="acao" value="salvar">
        <input type="hidden" name="id" id="fn-id">
        <div class="form-group"><label>Nome <span class="req">*</span></label><input type="text" name="nome" id="fn-nome" required></div>
        <div class="form-group"><label>Cargo <span class="req">*</span></label><input type="text" name="cargo" id="fn-cargo" required></div>
        <div class="form-row">
          <div class="form-group"><label>Telefone</label><input type="text" name="telefone" id="fn-tel"></div>
          <div class="form-group"><label>Salário (Kz)</label><input type="number" name="salario" id="fn-salario" min="0"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Data de entrada</label><input type="date" name="data_entrada" id="fn-data"></div>
          <div class="form-group">
            <label>Estado</label>
            <select name="estado" id="fn-estado">
              <option value="activa">Activa</option>
              <option value="inactiva">Inactiva</option>
              <option value="ferias">De férias</option>
            </select>
          </div>
        </div>
        <div class="form-group">
          <label>PIN individual (opcional — 4 dígitos)</label>
          <input type="text" name="novo_pin" id="fn-pin" maxlength="4" pattern="\d{4}" placeholder="Deixe em branco para manter o PIN geral">
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="fecharModal('modal-func')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
      </div>
    </form>
  </div>
</div>

<script>
function abrirNovaFuncionaria(){
  document.getElementById('modal-fn-title').textContent = 'Nova Funcionária';
  ['fn-id','fn-nome','fn-cargo','fn-tel','fn-salario','fn-data','fn-pin'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('fn-estado').value = 'activa';
  abrirModal('modal-func');
}
function abrirEditarFuncionaria(f){
  document.getElementById('modal-fn-title').textContent = 'Editar Funcionária — ' + f.nome;
  document.getElementById('fn-id').value = f.id;
  document.getElementById('fn-nome').value = f.nome;
  document.getElementById('fn-cargo').value = f.cargo;
  document.getElementById('fn-tel').value = f.telefone || '';
  document.getElementById('fn-salario').value = f.salario;
  document.getElementById('fn-data').value = f.data_entrada;
  document.getElementById('fn-estado').value = f.estado;
  document.getElementById('fn-pin').value = '';
  abrirModal('modal-func');
}
</script>

<?php require 'includes/footer.php'; ?>
