<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirLogin();

$hoje = hoje();

$totalClientes = $pdo->query("SELECT COUNT(*) n FROM clientes")->fetch()['n'];
$agHoje = $pdo->prepare("SELECT COUNT(*) n FROM agendamentos WHERE data = ?");
$agHoje->execute([$hoje]);
$agHojeCount = $agHoje->fetch()['n'];

$mesAtual = date('Y-m');
$stmtReceita = $pdo->prepare("SELECT COALESCE(SUM(valor),0) v FROM agendamentos WHERE estado IN ('confirmado','concluido') AND DATE_FORMAT(data,'%Y-%m') = ?");
$stmtReceita->execute([$mesAtual]);
$receitaMes = $stmtReceita->fetch()['v'];

$stmtSolPend = $pdo->query("SELECT COUNT(*) n FROM solicitacoes WHERE estado = 'pendente'");
$solPendentes = $stmtSolPend->fetch()['n'];

$stmtStockBaixo = $pdo->query("SELECT COUNT(*) n FROM stock WHERE quantidade <= quantidade_minima");
$stockBaixo = $stmtStockBaixo->fetch()['n'];

// Agenda de hoje
$stmtAgenda = $pdo->prepare("
    SELECT a.*, c.nome AS nome_cliente, s.nome AS nome_servico
    FROM agendamentos a
    JOIN clientes c ON c.id = a.id_cliente
    JOIN servicos s ON s.id = a.id_servico
    WHERE a.data = ?
    ORDER BY a.hora ASC
");
$stmtAgenda->execute([$hoje]);
$agendaHoje = $stmtAgenda->fetchAll();

$paginaAtiva = 'index';
$tituloPagina = 'Dashboard';
require 'includes/header.php';
?>

<div class="rel-cards" style="margin-bottom:20px;">
  <div class="stat-card"><div class="stat-label">Clientes</div><div class="stat-value"><?= $totalClientes ?></div><div class="stat-icon">◈</div></div>
  <div class="stat-card"><div class="stat-label">Agendamentos Hoje</div><div class="stat-value"><?= $agHojeCount ?></div><div class="stat-icon">◷</div></div>
  <div class="stat-card"><div class="stat-label">Receita do Mês</div><div class="stat-value" style="font-size:16px;"><?= fmtKz($receitaMes) ?></div><div class="stat-icon">◎</div></div>
  <div class="stat-card"><div class="stat-label">Solicitações Pendentes</div><div class="stat-value"><?= $solPendentes ?></div><div class="stat-icon">🔔</div></div>
</div>

<?php if($stockBaixo > 0): ?>
<div class="pin-error" style="display:block;margin-bottom:16px;">⚠️ Tens <?= $stockBaixo ?> produto(s) com stock baixo. Verifica a página de Stock.</div>
<?php endif; ?>

<div class="section-header">
  <div><div class="section-title">Agenda de Hoje</div><div class="section-sub"><?= fmtDataBR($hoje) ?></div></div>
</div>

<div class="table-wrap">
  <table>
    <thead><tr><th>Hora</th><th>Cliente</th><th>Serviço</th><th>Valor</th><th>Estado</th></tr></thead>
    <tbody>
      <?php if(!$agendaHoje): ?>
        <tr><td colspan="5"><div class="empty"><div class="empty-icon">◷</div><div class="empty-text">Sem agendamentos para hoje</div></div></td></tr>
      <?php else: foreach($agendaHoje as $a): ?>
        <tr>
          <td><?= substr($a['hora'],0,5) ?></td>
          <td class="td-main"><?= h($a['nome_cliente']) ?></td>
          <td><?= h($a['nome_servico']) ?></td>
          <td><?= fmtKz($a['valor']) ?></td>
          <td><?= badgeEstadoAgendamento($a['estado']) ?></td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php require 'includes/footer.php'; ?>
