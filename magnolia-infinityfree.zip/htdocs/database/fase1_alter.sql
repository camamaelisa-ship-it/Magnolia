-- =====================================================================
-- FASE 1 — MIGRAÇÃO: bloqueio por tentativas inválidas (RF015)
-- Corre este ficheiro no phpMyAdmin (aba "SQL") DEPOIS de já teres
-- importado o magnolia_beauty_salon_infinityfree.sql.
-- Adiciona colunas de controlo de tentativas de PIN erradas, tanto para
-- a administradora como para as funcionárias.
-- =====================================================================

ALTER TABLE `administradores`
  ADD COLUMN `tentativas_invalidas` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `pin_hash`,
  ADD COLUMN `bloqueado_ate` DATETIME NULL AFTER `tentativas_invalidas`;

ALTER TABLE `funcionarios`
  ADD COLUMN `tentativas_invalidas` INT UNSIGNED NOT NULL DEFAULT 0 AFTER `pin_hash`,
  ADD COLUMN `bloqueado_ate` DATETIME NULL AFTER `tentativas_invalidas`;

-- Nota: o PIN geral das funcionárias (configuracoes.pin_func_geral_hash)
-- não tem bloqueio próprio — o bloqueio é sempre por conta (id) individual.
