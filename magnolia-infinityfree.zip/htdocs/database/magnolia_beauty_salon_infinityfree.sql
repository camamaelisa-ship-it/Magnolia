-- =====================================================================
-- MAGNÓLIA BEAUTY SALON — BASE DE DADOS
-- Projecto de Engenharia de Software — Universidade de Belas
-- Compatível com: XAMPP (phpMyAdmin) e InfinityFree (phpMyAdmin)
-- Motor: MySQL / MariaDB | Charset: utf8mb4
-- =====================================================================
-- Esta base de dados foi desenhada para reflectir fielmente o modelo
-- de dados actualmente usado na aplicação (JavaScript + localStorage),
-- servindo de documentação formal (ex: diagrama ER) e como base para
-- uma futura migração do sistema para PHP + MySQL, caso seja necessário.
--
-- ✅ VERSÃO PRONTA PARA INFINITYFREE
-- Este ficheiro já não tem "CREATE DATABASE"/"USE" — importa-o directamente
-- dentro da tua base de dados if0_42414436_lauraprojeto no phpMyAdmin.
-- =====================================================================

-- (CREATE DATABASE / USE removidos nesta versão — já estás dentro da
-- base de dados if0_42414436_lauraprojeto, atribuída pelo InfinityFree)

SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- TABELA: configuracoes
-- Guarda pares chave/valor de configuração geral do sistema
-- (nome do salão, nome da administradora, número de WhatsApp, taxa de
-- comissão, tema, etc.) — equivalente ao que hoje está no localStorage.
-- ---------------------------------------------------------------------
CREATE TABLE `configuracoes` (
  `chave`  VARCHAR(60)  NOT NULL,
  `valor`  VARCHAR(255) NOT NULL,
  PRIMARY KEY (`chave`)
) ENGINE=InnoDB;

INSERT INTO `configuracoes` (`chave`, `valor`) VALUES
  ('nome_salao', 'Magnólia Beauty Salon'),
  ('nome_admin', 'Laura'),
  ('wa_numero', '958391756'),
  ('taxa_comissao', '15'),
  ('pin_func_geral_hash', '$2y$10$SUBSTITUIR_PELO_HASH_REAL_DO_PIN_0000'),
  ('tema', 'dark');

-- ---------------------------------------------------------------------
-- TABELA: administradores
-- Conta(s) de administração (acesso total ao sistema).
-- pin_hash deve guardar o PIN cifrado (ex: password_hash em PHP/bcrypt).
-- ---------------------------------------------------------------------
CREATE TABLE `administradores` (
  `id`         INT UNSIGNED AUTO_INCREMENT,
  `nome`       VARCHAR(100) NOT NULL,
  `pin_hash`   VARCHAR(255) NOT NULL,
  `criado_em`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- PIN de exemplo '1234' (substituir por hash real gerado em PHP: password_hash('1234', PASSWORD_BCRYPT))
INSERT INTO `administradores` (`nome`, `pin_hash`) VALUES
  ('Laura', '$2y$10$SUBSTITUIR_PELO_HASH_REAL_DO_PIN_1234');

-- ---------------------------------------------------------------------
-- TABELA: funcionarios
-- Equipa do salão. `estado` controla se está activa, inactiva ou de férias.
-- `pin_hash` é opcional — permite PIN individual por funcionária
-- (se NULL, o sistema usa o PIN geral guardado em
-- configuracoes.pin_func_geral_hash).
-- ---------------------------------------------------------------------
CREATE TABLE `funcionarios` (
  `id`            INT UNSIGNED AUTO_INCREMENT,
  `nome`          VARCHAR(100) NOT NULL,
  `cargo`         VARCHAR(100) NOT NULL,
  `telefone`      VARCHAR(20)  NOT NULL,
  `salario`       DECIMAL(10,2) NOT NULL DEFAULT 0,
  `data_entrada`  DATE NOT NULL,
  `estado`        ENUM('activa','inactiva','ferias') NOT NULL DEFAULT 'activa',
  `pin_hash`      VARCHAR(255) NULL,
  `criado_em`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

INSERT INTO `funcionarios` (`nome`,`cargo`,`telefone`,`salario`,`data_entrada`,`estado`) VALUES
  ('Sofia Mendes','Cabeleireira Sénior','923 111 222',120000.00,'2024-01-01','activa'),
  ('Joana Carlos','Manicure & Pedicure','934 222 333',90000.00,'2024-06-01','activa');

-- ---------------------------------------------------------------------
-- TABELA: clientes
-- RN001: telefone e e-mail devem ser únicos (evita registos duplicados).
-- ---------------------------------------------------------------------
CREATE TABLE `clientes` (
  `id`            INT UNSIGNED AUTO_INCREMENT,
  `nome`          VARCHAR(150) NOT NULL,
  `telefone`      VARCHAR(20)  NOT NULL,
  `email`         VARCHAR(150) NULL,
  `bairro`        VARCHAR(100) NULL,
  `tipo_cabelo`   VARCHAR(60)  NULL,
  `alergia`       VARCHAR(255) NULL,
  `observacoes`   TEXT NULL,
  `criado_em`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_clientes_telefone` (`telefone`),
  UNIQUE KEY `uq_clientes_email` (`email`)
) ENGINE=InnoDB;

INSERT INTO `clientes` (`nome`,`telefone`,`email`,`bairro`,`tipo_cabelo`,`alergia`,`observacoes`) VALUES
  ('Ana Beatriz Sousa','923 456 789','ana@email.com','Maianga','Cabelo Liso',NULL,NULL),
  ('Maria da Graça','912 345 678','maria@email.com','Rangel','Cabelo Afro','alergia a amónia','Prefere produtos naturais'),
  ('Carla Fernandes','934 567 890','carla@email.com','Samba','Cabelo Ondulado',NULL,NULL);

-- ---------------------------------------------------------------------
-- TABELA: servicos
-- RN001: nome do serviço deve ser único.
-- ---------------------------------------------------------------------
CREATE TABLE `servicos` (
  `id`         INT UNSIGNED AUTO_INCREMENT,
  `nome`       VARCHAR(150) NOT NULL,
  `categoria`  VARCHAR(60)  NOT NULL,
  `preco`      DECIMAL(10,2) NOT NULL,
  `duracao`    INT UNSIGNED NOT NULL COMMENT 'duração em minutos',
  `descricao`  TEXT NULL,
  `criado_em`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_servicos_nome` (`nome`)
) ENGINE=InnoDB;

INSERT INTO `servicos` (`nome`,`categoria`,`preco`,`duracao`,`descricao`) VALUES
  ('Tranças Box Braids','cabelo',8000.00,180,'Tranças box braids completas com extensão inclusa'),
  ('Manicure Gel','unhas',3500.00,60,'Manicure completa com verniz gel de longa duração'),
  ('Tratamento Facial','pele',5500.00,75,'Limpeza de pele profunda com produtos premium'),
  ('Penteado de Festa','cabelo',6000.00,90,'Penteado elaborado para eventos especiais');

-- ---------------------------------------------------------------------
-- TABELA: stock
-- RN001: nome do produto deve ser único.
-- ---------------------------------------------------------------------
CREATE TABLE `stock` (
  `id`                  INT UNSIGNED AUTO_INCREMENT,
  `nome`                VARCHAR(150) NOT NULL,
  `categoria`           VARCHAR(60)  NOT NULL,
  `quantidade`          INT NOT NULL DEFAULT 0,
  `quantidade_minima`   INT NOT NULL DEFAULT 0,
  `unidade`             VARCHAR(10)  NOT NULL DEFAULT 'un',
  `preco`               DECIMAL(10,2) NOT NULL,
  `criado_em`           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_stock_nome` (`nome`)
) ENGINE=InnoDB;

INSERT INTO `stock` (`nome`,`categoria`,`quantidade`,`quantidade_minima`,`unidade`,`preco`) VALUES
  ('Shampoo Keratina','cabelo',12,5,'un',3500.00),
  ('Tinta Capilar Preta','cabelo',3,5,'un',2000.00),
  ('Verniz Gel Rosa','unhas',8,3,'un',1500.00),
  ('Creme Hidratante Facial','pele',2,5,'un',4000.00),
  ('Acetona','unhas',5,3,'L',800.00);

-- ---------------------------------------------------------------------
-- TABELA: agendamentos
-- Marcações confirmadas / concluídas / canceladas no calendário do salão.
-- ---------------------------------------------------------------------
CREATE TABLE `agendamentos` (
  `id`               INT UNSIGNED AUTO_INCREMENT,
  `id_cliente`       INT UNSIGNED NOT NULL,
  `id_servico`       INT UNSIGNED NOT NULL,
  `id_funcionaria`   INT UNSIGNED NULL,
  `data`             DATE NOT NULL,
  `hora`             TIME NOT NULL,
  `estado`           ENUM('pendente','confirmado','concluido','cancelado') NOT NULL DEFAULT 'pendente',
  `valor`            DECIMAL(10,2) NOT NULL,
  `observacoes`      TEXT NULL,
  `criado_em`        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_agendamentos_data` (`data`),
  CONSTRAINT `fk_ag_cliente`     FOREIGN KEY (`id_cliente`)     REFERENCES `clientes`(`id`)     ON DELETE CASCADE,
  CONSTRAINT `fk_ag_servico`     FOREIGN KEY (`id_servico`)     REFERENCES `servicos`(`id`)     ON DELETE RESTRICT,
  CONSTRAINT `fk_ag_funcionaria` FOREIGN KEY (`id_funcionaria`) REFERENCES `funcionarios`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO `agendamentos` (`id_cliente`,`id_servico`,`id_funcionaria`,`data`,`hora`,`estado`,`valor`,`observacoes`) VALUES
  (1,1,1,'2026-06-20','09:00','confirmado',8000.00,''),
  (2,2,2,'2026-06-20','11:00','pendente',3500.00,''),
  (3,3,1,'2026-06-20','14:00','confirmado',5500.00,'');

-- ---------------------------------------------------------------------
-- TABELA: solicitacoes
-- Pedidos de agendamento feitos pela cliente (público, sem sessão) através
-- do ecrã de acesso. O admin/funcionária confirma, recusa ou reagenda.
-- Quando confirmado, gera automaticamente um registo em `agendamentos`
-- (id_agendamento faz a ligação).
-- ---------------------------------------------------------------------
CREATE TABLE `solicitacoes` (
  `id`              INT UNSIGNED AUTO_INCREMENT,
  `nome`            VARCHAR(150) NOT NULL,
  `telefone`        VARCHAR(20)  NOT NULL,
  `id_servico`      INT UNSIGNED NOT NULL,
  `data`            DATE NOT NULL,
  `hora`            TIME NOT NULL,
  `observacoes`     TEXT NULL,
  `estado`          ENUM('pendente','confirmado','reagendado','recusado') NOT NULL DEFAULT 'pendente',
  `id_agendamento`  INT UNSIGNED NULL,
  `criado_em`       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_sol_servico`     FOREIGN KEY (`id_servico`)     REFERENCES `servicos`(`id`)     ON DELETE RESTRICT,
  CONSTRAINT `fk_sol_agendamento` FOREIGN KEY (`id_agendamento`) REFERENCES `agendamentos`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABELA: faturas
-- Facturas emitidas a partir do carrinho de compras (serviços/produtos).
-- `id_cliente` obrigatório (RN: a cliente deve ser seleccionada antes de
-- gerar a factura). `nome_cliente` é uma cópia (snapshot) do nome no
-- momento da emissão, para preservar o histórico mesmo que o registo
-- do cliente seja depois alterado.
-- ---------------------------------------------------------------------
CREATE TABLE `faturas` (
  `id`             INT UNSIGNED AUTO_INCREMENT,
  `id_cliente`     INT UNSIGNED NOT NULL,
  `nome_cliente`   VARCHAR(150) NOT NULL,
  `total`          DECIMAL(10,2) NOT NULL,
  `estado`         ENUM('emitida','cancelada') NOT NULL DEFAULT 'emitida',
  `emitido_por`    VARCHAR(100) NOT NULL,
  `criado_em`      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_fat_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `clientes`(`id`) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABELA: fatura_itens
-- Linhas de cada factura (serviços e/ou produtos vendidos).
-- `nome` e `preco` são também um snapshot (o preço pode mudar depois,
-- mas a factura deve manter o valor cobrado na altura da venda).
-- ---------------------------------------------------------------------
CREATE TABLE `fatura_itens` (
  `id`             INT UNSIGNED AUTO_INCREMENT,
  `id_fatura`      INT UNSIGNED NOT NULL,
  `tipo`           ENUM('servico','produto') NOT NULL,
  `id_referencia`  INT UNSIGNED NOT NULL COMMENT 'id do serviço ou produto de stock',
  `nome`           VARCHAR(150) NOT NULL,
  `preco`          DECIMAL(10,2) NOT NULL,
  `quantidade`     INT UNSIGNED NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_fi_fatura` FOREIGN KEY (`id_fatura`) REFERENCES `faturas`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- TABELA: financeiro
-- Lançamentos de receitas e despesas (inclui as receitas geradas
-- automaticamente a partir das faturas).
-- ---------------------------------------------------------------------
CREATE TABLE `financeiro` (
  `id`          INT UNSIGNED AUTO_INCREMENT,
  `descricao`   VARCHAR(200) NOT NULL,
  `tipo`        ENUM('receita','despesa') NOT NULL,
  `categoria`   VARCHAR(60) NOT NULL,
  `valor`       DECIMAL(10,2) NOT NULL,
  `data`        DATE NOT NULL,
  `criado_em`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

INSERT INTO `financeiro` (`descricao`,`tipo`,`categoria`,`valor`,`data`) VALUES
  ('Pagamento Manicure','receita','servico',3500.00,'2026-06-03'),
  ('Compra produtos capilares','despesa','material',15000.00,'2026-06-02'),
  ('Pagamento Box Braids','receita','servico',9000.00,'2026-06-01'),
  ('Renda do salão','despesa','renda',50000.00,'2026-06-01');

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- FIM DO SCRIPT
-- =====================================================================
