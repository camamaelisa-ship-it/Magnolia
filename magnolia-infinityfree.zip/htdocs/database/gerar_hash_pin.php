<?php
/**
 * GERAR HASH DE PIN — Magnólia Beauty Salon
 * -----------------------------------------------------------------
 * Este script serve só para gerares o hash bcrypt real de um PIN,
 * para depois colares no phpMyAdmin (colunas pin_hash / pin_func_geral_hash).
 *
 * COMO USAR:
 * 1) Carrega este ficheiro para o teu site (InfinityFree ou XAMPP).
 * 2) Abre no navegador, por exemplo:
 *      https://o-teu-site.com/gerar_hash_pin.php?pin=1234
 *    (troca "1234" pelo PIN que quiseres gerar — 4 dígitos)
 * 3) Copia o hash gerado e cola no phpMyAdmin, na coluna certa.
 * 4) Depois de gerares os hashes que precisas, APAGA este ficheiro
 *    do servidor (não deve ficar publicado, por segurança).
 * -----------------------------------------------------------------
 */

$pin = isset($_GET['pin']) ? $_GET['pin'] : '1234';

if(!preg_match('/^\d{4,6}$/', $pin)){
    die("<p style='color:red;font-family:sans-serif;'>PIN inválido. Usa só dígitos (4 a 6 números). Exemplo: ?pin=1234</p>");
}

$hash = password_hash($pin, PASSWORD_BCRYPT);
?>
<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><title>Gerador de Hash de PIN</title></head>
<body style="font-family:sans-serif;max-width:600px;margin:30px auto;padding:0 16px;">
  <h2>🔐 Gerador de Hash de PIN</h2>
  <p><strong>PIN:</strong> <?php echo htmlspecialchars($pin); ?></p>
  <p><strong>Hash gerado (copia tudo):</strong></p>
  <textarea rows="3" style="width:100%;font-size:14px;" readonly onclick="this.select();"><?php echo htmlspecialchars($hash); ?></textarea>
  <p style="color:#555;font-size:13px;">Cola este hash na coluna <code>pin_hash</code> (tabela <code>administradores</code> ou <code>funcionarios</code>) ou em <code>configuracoes.valor</code> (linha da chave <code>pin_func_geral_hash</code>).</p>
  <p style="color:#b00;font-size:13px;">⚠️ Depois de usares, apaga este ficheiro do servidor.</p>
  <hr>
  <p style="font-size:13px;">Para gerar outro PIN, muda o número no fim do link, ex: <code>?pin=5678</code></p>
</body>
</html>

