<?php
require_once 'includes/auth.php';

if (estaLogado()) {
    header('Location: index.php');
    exit;
}

$mensagem = '';
$role = $_POST['role'] ?? 'admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pin = trim($_POST['pin'] ?? '');

    if (!preg_match('/^\d{4}$/', $pin)) {
        $mensagem = 'Introduza um PIN válido de 4 dígitos.';
    } elseif ($role === 'admin') {
        $res = autenticarAdmin($pdo, $pin);
        if ($res['ok']) { header('Location: index.php'); exit; }
        $mensagem = $res['msg'];
    } else {
        $idFunc = (int)($_POST['id_funcionaria'] ?? 0);
        if (!$idFunc) {
            $mensagem = 'Seleccione a sua conta.';
        } else {
            $res = autenticarFuncionaria($pdo, $idFunc, $pin);
            if ($res['ok']) { header('Location: index.php'); exit; }
            $mensagem = $res['msg'];
        }
    }
}

// Lista de funcionárias activas para o dropdown
$funcionarias = $pdo->query("SELECT id, nome FROM funcionarios WHERE estado = 'activa' ORDER BY nome ASC")->fetchAll();
$nomeSalao = getConfig($pdo, 'nome_salao', 'Magnólia Beauty Salon');
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — <?= htmlspecialchars($nomeSalao) ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div id="login-screen">
  <div class="login-box">
    <div class="login-logo">✿</div>
    <div class="login-title"><?= htmlspecialchars($nomeSalao) ?></div>
    <div class="login-sub">Acesso restrito à equipa</div>

    <div class="login-role-tabs">
      <button type="button" class="role-tab <?= $role==='admin'?'active':'' ?>" onclick="selecionarRole('admin')">👑 Administradora</button>
      <button type="button" class="role-tab <?= $role==='funcionaria'?'active':'' ?>" onclick="selecionarRole('funcionaria')">✂ Funcionária</button>
    </div>

    <?php if ($mensagem): ?>
      <div class="pin-error" style="display:block;"><?= htmlspecialchars($mensagem) ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php" id="form-login">
      <input type="hidden" name="role" id="input-role" value="<?= htmlspecialchars($role) ?>">
      <input type="hidden" name="pin" id="input-pin" value="">

      <div id="func-selector" style="<?= $role==='funcionaria'?'':'display:none;' ?>margin-bottom:16px;">
        <div class="pin-label">Seleccione a sua conta</div>
        <select name="id_funcionaria" id="func-select-id" style="width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px 12px;color:var(--text);font-size:13px;font-family:'DM Sans',sans-serif;outline:none;">
          <option value="">-- Seleccionar funcionária --</option>
          <?php foreach ($funcionarias as $f): ?>
            <option value="<?= $f['id'] ?>"><?= htmlspecialchars($f['nome']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="pin-label">Código de acesso (4 dígitos)</div>
      <div class="pin-row" id="pin-dots">
        <div class="pin-dot" id="d0">–</div>
        <div class="pin-dot" id="d1">–</div>
        <div class="pin-dot" id="d2">–</div>
        <div class="pin-dot" id="d3">–</div>
      </div>

      <div class="numpad">
        <button type="button" class="num-btn" onclick="pinPress('1')">1</button>
        <button type="button" class="num-btn" onclick="pinPress('2')">2</button>
        <button type="button" class="num-btn" onclick="pinPress('3')">3</button>
        <button type="button" class="num-btn" onclick="pinPress('4')">4</button>
        <button type="button" class="num-btn" onclick="pinPress('5')">5</button>
        <button type="button" class="num-btn" onclick="pinPress('6')">6</button>
        <button type="button" class="num-btn" onclick="pinPress('7')">7</button>
        <button type="button" class="num-btn" onclick="pinPress('8')">8</button>
        <button type="button" class="num-btn" onclick="pinPress('9')">9</button>
        <button type="button" class="num-btn del-btn" onclick="pinDel()">⌫</button>
        <button type="button" class="num-btn" onclick="pinPress('0')">0</button>
        <button type="button" class="num-btn ok-btn" onclick="pinConfirm()">✓</button>
      </div>
    </form>
    <div class="staff-access-link" onclick="window.location.href='public_agendar.php'">📅 Sou cliente — Marcar Agendamento</div>
  </div>
</div>

<script>
let pinAtual = '';

function selecionarRole(role){
  document.getElementById('input-role').value = role;
  document.querySelectorAll('.role-tab').forEach(t=>t.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('func-selector').style.display = (role==='funcionaria') ? 'block' : 'none';
  limparPin();
}

function atualizarPontos(){
  for(let i=0;i<4;i++){
    document.getElementById('d'+i).textContent = i < pinAtual.length ? '●' : '–';
  }
}

function pinPress(digito){
  if(pinAtual.length >= 4) return;
  pinAtual += digito;
  atualizarPontos();
}

function pinDel(){
  pinAtual = pinAtual.slice(0,-1);
  atualizarPontos();
}

function limparPin(){
  pinAtual = '';
  atualizarPontos();
}

function pinConfirm(){
  if(pinAtual.length !== 4){
    alert('Introduza os 4 dígitos do PIN.');
    return;
  }
  const role = document.getElementById('input-role').value;
  if(role === 'funcionaria' && !document.getElementById('func-select-id').value){
    alert('Seleccione a sua conta antes de continuar.');
    return;
  }
  document.getElementById('input-pin').value = pinAtual;
  document.getElementById('form-login').submit();
}
</script>
</body>
</html>
