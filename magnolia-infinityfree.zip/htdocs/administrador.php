<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $acao = $_POST['acao'] ?? '';

    if($acao === 'identidade'){
        $nomeSalaoNovo = trim($_POST['nome_salao']);
        $waNumeroNovo = trim($_POST['wa_numero']);
        $taxaNova = (int)$_POST['taxa_comissao'];

        if($nomeSalaoNovo === ''){ setFlash('O nome do salão não pode ficar vazio.','error'); redirecionar('administrador.php'); }
        if(!preg_match('/^\d{7,15}$/', $waNumeroNovo)){ setFlash('Número de WhatsApp inválido. Use apenas dígitos, ex: 958391756','error'); redirecionar('administrador.php'); }

        setConfig($pdo, 'nome_salao', $nomeSalaoNovo);
        setConfig($pdo, 'wa_numero', $waNumeroNovo);
        setConfig($pdo, 'taxa_comissao', $taxaNova);
        setFlash('Identidade do salão actualizada!');
        redirecionar('administrador.php');
    }

    if($acao === 'mudar_pin_admin'){
        $novoPin = trim($_POST['novo_pin']);
        if(!preg_match('/^\d{4}$/', $novoPin)){
            setFlash('O PIN deve ter exactamente 4 dígitos.','error');
            redirecionar('administrador.php');
        }
        $hash = password_hash($novoPin, PASSWORD_BCRYPT);
        $stmt = $pdo->prepare("UPDATE administradores SET pin_hash=?, tentativas_invalidas=0, bloqueado_ate=NULL WHERE id=?");
        $stmt->execute([$hash, $_SESSION['id']]);
        setFlash('PIN da administradora actualizado!');
        redirecionar('administrador.php');
    }

    if($acao === 'mudar_pin_geral'){
        $novoPin = trim($_POST['novo_pin_geral']);
        if(!preg_match('/^\d{4}$/', $novoPin)){
            setFlash('O PIN deve ter exactamente 4 dígitos.','error');
            redirecionar('administrador.php');
        }
        $hash = password_hash($novoPin, PASSWORD_BCRYPT);
        setConfig($pdo, 'pin_func_geral_hash', $hash);
        setFlash('PIN geral das funcionárias actualizado!');
        redirecionar('administrador.php');
    }

    if($acao === 'mudar_nome_admin'){
        $novoNome = trim($_POST['novo_nome']);
        if($novoNome === ''){ setFlash('O nome não pode ficar vazio.','error'); redirecionar('administrador.php'); }
        $stmt = $pdo->prepare("UPDATE administradores SET nome=? WHERE id=?");
        $stmt->execute([$novoNome, $_SESSION['id']]);
        $_SESSION['nome'] = $novoNome;
        setFlash('Nome actualizado!');
        redirecionar('administrador.php');
    }
}

$nomeSalao = getConfig($pdo, 'nome_salao', 'Magnólia Beauty Salon');
$waNumero = getConfig($pdo, 'wa_numero', '958391756');
$taxaComissao = getConfig($pdo, 'taxa_comissao', 15);

$paginaAtiva = 'administrador';
$tituloPagina = 'Administrador';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Administrador</div><div class="section-sub">Configurações gerais do sistema</div></div>
</div>

<div class="card" style="max-width:480px;margin-bottom:16px;">
  <div style="font-weight:600;margin-bottom:12px;">Identidade do Salão</div>
  <form method="POST">
    <input type="hidden" name="acao" value="identidade">
    <div class="form-group"><label>Nome do salão</label><input type="text" name="nome_salao" value="<?= h($nomeSalao) ?>"></div>
    <div class="form-group"><label>Número de WhatsApp (sem +244)</label><input type="text" name="wa_numero" value="<?= h($waNumero) ?>" placeholder="958391756"></div>
    <div class="form-group"><label>Taxa de comissão das funcionárias (%)</label><input type="number" name="taxa_comissao" value="<?= h($taxaComissao) ?>" min="0" max="100"></div>
    <button class="btn btn-primary" type="submit" style="width:100%;">Guardar</button>
  </form>
</div>

<div class="card" style="max-width:480px;margin-bottom:16px;">
  <div style="font-weight:600;margin-bottom:12px;">O Meu Nome</div>
  <form method="POST">
    <input type="hidden" name="acao" value="mudar_nome_admin">
    <div class="form-group"><label>Nome</label><input type="text" name="novo_nome" value="<?= h($_SESSION['nome']) ?>"></div>
    <button class="btn btn-ghost" type="submit" style="width:100%;">Actualizar Nome</button>
  </form>
</div>

<div class="card" style="max-width:480px;margin-bottom:16px;">
  <div style="font-weight:600;margin-bottom:12px;">Mudar o Meu PIN de Acesso</div>
  <form method="POST">
    <input type="hidden" name="acao" value="mudar_pin_admin">
    <div class="form-group"><label>Novo PIN (4 dígitos)</label><input type="text" name="novo_pin" maxlength="4" pattern="\d{4}" required></div>
    <button class="btn btn-ghost" type="submit" style="width:100%;">Actualizar Meu PIN</button>
  </form>
</div>

<div class="card" style="max-width:480px;">
  <div style="font-weight:600;margin-bottom:12px;">PIN Geral das Funcionárias</div>
  <div style="font-size:12px;color:var(--text3);margin-bottom:10px;">Usado pelas funcionárias que não têm um PIN individual definido (ver página Funcionários).</div>
  <form method="POST">
    <input type="hidden" name="acao" value="mudar_pin_geral">
    <div class="form-group"><label>Novo PIN geral (4 dígitos)</label><input type="text" name="novo_pin_geral" maxlength="4" pattern="\d{4}" required></div>
    <button class="btn btn-ghost" type="submit" style="width:100%;">Actualizar PIN Geral</button>
  </form>
</div>

<?php require 'includes/footer.php'; ?>
