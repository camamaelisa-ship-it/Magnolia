<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirAdmin();

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $acao = $_POST['acao'] ?? '';

    if($acao === 'salvar'){
        $id = (int)($_POST['id'] ?? 0);
        $nome = trim($_POST['nome']);
        $categoria = trim($_POST['categoria']);
        $qtd = (int)$_POST['quantidade'];
        $min = (int)($_POST['quantidade_minima'] ?? 0);
        $unidade = trim($_POST['unidade'] ?? 'un');
        $preco = (float)$_POST['preco'];

        if($nome === ''){
            setFlash('Nome é obrigatório.','error');
            redirecionar('stock.php');
        }

        // RN001 — nome do produto deve ser único
        $stmtDup = $pdo->prepare("SELECT id FROM stock WHERE LOWER(nome) = LOWER(?) AND id <> ?");
        $stmtDup->execute([$nome, $id]);
        if($stmtDup->fetch()){
            setFlash('RN001: já existe um produto com este nome.','error');
            redirecionar('stock.php');
        }

        if($id){
            $stmt = $pdo->prepare("UPDATE stock SET nome=?, categoria=?, quantidade=?, quantidade_minima=?, unidade=?, preco=? WHERE id=?");
            $stmt->execute([$nome,$categoria,$qtd,$min,$unidade,$preco,$id]);
            setFlash('Produto actualizado!');
        } else {
            $stmt = $pdo->prepare("INSERT INTO stock (nome,categoria,quantidade,quantidade_minima,unidade,preco) VALUES (?,?,?,?,?,?)");
            $stmt->execute([$nome,$categoria,$qtd,$min,$unidade,$preco]);
            setFlash('Produto adicionado!');
        }
        redirecionar('stock.php');
    }

    if($acao === 'apagar'){
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM stock WHERE id=?");
        $stmt->execute([$id]);
        setFlash('Produto removido.','warn');
        redirecionar('stock.php');
    }
}

$busca = trim($_GET['q'] ?? '');
$sql = "SELECT * FROM stock";
$params = [];
if($busca){ $sql .= " WHERE nome LIKE ?"; $params[] = "%$busca%"; }
$sql .= " ORDER BY nome ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$stock = $stmt->fetchAll();

$paginaAtiva = 'stock';
$tituloPagina = 'Stock';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Stock</div><div class="section-sub">Gestão de produtos do salão</div></div>
  <button class="btn btn-primary" onclick="abrirNovoProduto()">+ Novo Produto</button>
</div>

<form method="GET" style="margin-bottom:14px;">
  <input type="text" name="q" placeholder="Procurar produto..." value="<?= h($busca) ?>" style="width:100%;max-width:320px;">
</form>

<div class="table-wrap">
  <table>
    <thead><tr><th>Produto</th><th>Categoria</th><th>Quantidade</th><th>Mínimo</th><th>Preço</th><th>Acções</th></tr></thead>
    <tbody>
      <?php if(!$stock): ?>
        <tr><td colspan="6"><div class="empty"><div class="empty-icon">📦</div><div class="empty-text">Nenhum produto em stock</div></div></td></tr>
      <?php else: foreach($stock as $s):
          $baixo = $s['quantidade'] <= $s['quantidade_minima'];
      ?>
        <tr>
          <td class="td-main"><?= h($s['nome']) ?> <?php if($baixo): ?><span title="Stock baixo">⚠️</span><?php endif; ?></td>
          <td><?= ucfirst($s['categoria']) ?></td>
          <td style="<?= $baixo ? 'color:var(--red);font-weight:600;' : '' ?>"><?= $s['quantidade'] ?> <?= h($s['unidade']) ?></td>
          <td><?= $s['quantidade_minima'] ?></td>
          <td><?= fmtKz($s['preco']) ?></td>
          <td>
            <div class="actions" style="display:flex;gap:6px;">
              <button class="action-btn" onclick='abrirEditarProduto(<?= json_encode($s) ?>)'>✎</button>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Remover este produto?');">
                <input type="hidden" name="acao" value="apagar">
                <input type="hidden" name="id" value="<?= $s['id'] ?>">
                <button class="action-btn del" type="submit">🗑</button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<div class="modal-overlay" id="modal-stock">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title" id="modal-stk-title">Novo Produto</div>
      <button class="modal-close" onclick="fecharModal('modal-stock')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="acao" value="salvar">
        <input type="hidden" name="id" id="stk-id">
        <div class="form-group"><label>Nome <span class="req">*</span></label><input type="text" name="nome" id="stk-nome" required></div>
        <div class="form-group">
          <label>Categoria</label>
          <select name="categoria" id="stk-cat">
            <option value="cabelo">Cabelo</option>
            <option value="unhas">Unhas</option>
            <option value="pele">Pele</option>
          </select>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Quantidade <span class="req">*</span></label><input type="number" name="quantidade" id="stk-qtd" min="0" required></div>
          <div class="form-group"><label>Mínimo</label><input type="number" name="quantidade_minima" id="stk-min" min="0" value="0"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Unidade</label><input type="text" name="unidade" id="stk-und" value="un"></div>
          <div class="form-group"><label>Preço (Kz)</label><input type="number" name="preco" id="stk-preco" min="0" required></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="fecharModal('modal-stock')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
      </div>
    </form>
  </div>
</div>

<script>
function abrirNovoProduto(){
  document.getElementById('modal-stk-title').textContent = 'Novo Produto';
  ['stk-id','stk-nome','stk-qtd','stk-preco'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('stk-cat').value = 'cabelo';
  document.getElementById('stk-min').value = 0;
  document.getElementById('stk-und').value = 'un';
  abrirModal('modal-stock');
}
function abrirEditarProduto(s){
  document.getElementById('modal-stk-title').textContent = 'Editar Produto';
  document.getElementById('stk-id').value = s.id;
  document.getElementById('stk-nome').value = s.nome;
  document.getElementById('stk-cat').value = s.categoria;
  document.getElementById('stk-qtd').value = s.quantidade;
  document.getElementById('stk-min').value = s.quantidade_minima;
  document.getElementById('stk-und').value = s.unidade;
  document.getElementById('stk-preco').value = s.preco;
  abrirModal('modal-stock');
}
</script>

<?php require 'includes/footer.php'; ?>
