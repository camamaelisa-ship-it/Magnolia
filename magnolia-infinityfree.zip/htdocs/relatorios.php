<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirAdmin();

$ini = $_GET['ini'] ?? date('Y-m-01');
$fim = $_GET['fim'] ?? hoje();

$stmt = $pdo->prepare("SELECT * FROM faturas WHERE DATE(data) BETWEEN ? AND ? ORDER BY data DESC");
$stmt->execute([$ini, $fim]);
$faturas = $stmt->fetchAll();

$emitidas = array_filter($faturas, fn($f)=>$f['estado']!=='cancelada');
$canceladas = array_filter($faturas, fn($f)=>$f['estado']==='cancelada');
$totalFaturado = array_reduce($emitidas, fn($s,$f)=>$s+$f['total'], 0);

$servMap = []; $prodMap = [];
if($emitidas){
    $ids = array_map(fn($f)=>$f['id'], $emitidas);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmtItens = $pdo->prepare("SELECT * FROM fatura_itens WHERE id_fatura IN ($placeholders)");
    $stmtItens->execute($ids);
    foreach($stmtItens->fetchAll() as $it){
        $alvo = $it['tipo']==='servico' ? 'servMap' : 'prodMap';
        if($alvo === 'servMap'){
            if(!isset($servMap[$it['nome']])) $servMap[$it['nome']] = ['qtd'=>0,'total'=>0];
            $servMap[$it['nome']]['qtd'] += $it['quantidade'];
            $servMap[$it['nome']]['total'] += $it['preco']*$it['quantidade'];
        } else {
            if(!isset($prodMap[$it['nome']])) $prodMap[$it['nome']] = ['qtd'=>0,'total'=>0];
            $prodMap[$it['nome']]['qtd'] += $it['quantidade'];
            $prodMap[$it['nome']]['total'] += $it['preco']*$it['quantidade'];
        }
    }
}
arsort($servMap); arsort($prodMap);
$topServicos = array_slice($servMap, 0, 10, true);
$topProdutos = array_slice($prodMap, 0, 10, true);

$paginaAtiva = 'relatorios';
$tituloPagina = 'Relatórios';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Relatórios</div><div class="section-sub">Faturação por período</div></div>
  <a class="btn btn-ghost btn-sm" style="text-decoration:none;" href="relatorio_pdf.php?ini=<?= h($ini) ?>&fim=<?= h($fim) ?>" target="_blank">⬇ Exportar PDF</a>
</div>

<form method="GET" style="display:flex;gap:8px;margin-bottom:18px;flex-wrap:wrap;">
  <input type="date" name="ini" value="<?= h($ini) ?>">
  <input type="date" name="fim" value="<?= h($fim) ?>">
  <button class="btn btn-ghost" type="submit">Filtrar</button>
</form>

<div class="rel-cards">
  <div class="stat-card"><div class="stat-label">Faturas Emitidas</div><div class="stat-value"><?= count($emitidas) ?></div><div class="stat-icon">🧾</div></div>
  <div class="stat-card"><div class="stat-label">Faturas Canceladas</div><div class="stat-value"><?= count($canceladas) ?></div><div class="stat-icon">✕</div></div>
  <div class="stat-card"><div class="stat-label">Total Faturado</div><div class="stat-value" style="font-size:16px;"><?= fmtKz($totalFaturado) ?></div><div class="stat-icon">◎</div></div>
</div>

<div style="display:flex;gap:16px;flex-wrap:wrap;margin:18px 0;">
  <div style="flex:1;min-width:280px;">
    <div style="font-weight:600;margin-bottom:8px;">Serviços Mais Vendidos</div>
    <div class="table-wrap"><table><thead><tr><th>Serviço</th><th>Qtd</th><th>Total</th></tr></thead><tbody>
      <?php if(!$topServicos): ?><tr><td colspan="3" style="text-align:center;color:var(--text3);">Sem dados.</td></tr><?php else: foreach($topServicos as $nome=>$v): ?>
        <tr><td><?= h($nome) ?></td><td><?= $v['qtd'] ?></td><td><?= fmtKz($v['total']) ?></td></tr>
      <?php endforeach; endif; ?>
    </tbody></table></div>
  </div>
  <div style="flex:1;min-width:280px;">
    <div style="font-weight:600;margin-bottom:8px;">Produtos Mais Vendidos</div>
    <div class="table-wrap"><table><thead><tr><th>Produto</th><th>Qtd</th><th>Total</th></tr></thead><tbody>
      <?php if(!$topProdutos): ?><tr><td colspan="3" style="text-align:center;color:var(--text3);">Sem dados.</td></tr><?php else: foreach($topProdutos as $nome=>$v): ?>
        <tr><td><?= h($nome) ?></td><td><?= $v['qtd'] ?></td><td><?= fmtKz($v['total']) ?></td></tr>
      <?php endforeach; endif; ?>
    </tbody></table></div>
  </div>
</div>

<div style="font-weight:600;margin-bottom:8px;">Faturas no Período</div>
<div class="table-wrap">
  <table>
    <thead><tr><th>Nº</th><th>Data</th><th>Cliente</th><th>Valor</th><th>Estado</th></tr></thead>
    <tbody>
      <?php if(!$faturas): ?>
        <tr><td colspan="5" style="text-align:center;color:var(--text3);">Nenhuma fatura no período seleccionado.</td></tr>
      <?php else: foreach($faturas as $f): ?>
        <tr>
          <td>#<?= str_pad($f['id'],6,'0',STR_PAD_LEFT) ?></td>
          <td><?= fmtDataBR(substr($f['data'],0,10)) ?></td>
          <td><?= h($f['nome_cliente'] ?? '—') ?></td>
          <td><?= fmtKz($f['total']) ?></td>
          <td><?= $f['estado']==='cancelada' ? '<span class="badge badge-red">Cancelada</span>' : '<span class="badge badge-green">Emitida</span>' ?></td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php require 'includes/footer.php'; ?>
