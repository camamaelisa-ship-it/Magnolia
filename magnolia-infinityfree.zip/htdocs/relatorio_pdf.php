<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirAdmin();

$ini = $_GET['ini'] ?? date('Y-m-01');
$fim = $_GET['fim'] ?? hoje();

$stmt = $pdo->prepare("SELECT * FROM faturas WHERE DATE(data) BETWEEN ? AND ? ORDER BY data DESC");
$stmt->execute([$ini, $fim]);
$faturas = $stmt->fetchAll();

$emitidas = array_filter($faturas, fn($f)=>$f['estado']!=='cancelada');
$canceladas = array_filter($faturas, fn($f)=>$f['estado']==='cancelada');
$totalFaturado = array_reduce($emitidas, fn($s,$f)=>$s+$f['total'], 0);

$servMap = []; $prodMap = [];
if($emitidas){
    $ids = array_map(fn($f)=>$f['id'], $emitidas);
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmtItens = $pdo->prepare("SELECT * FROM fatura_itens WHERE id_fatura IN ($placeholders)");
    $stmtItens->execute($ids);
    foreach($stmtItens->fetchAll() as $it){
        $alvo = $it['tipo']==='servico' ? 'servMap' : 'prodMap';
        if($alvo === 'servMap'){
            if(!isset($servMap[$it['nome']])) $servMap[$it['nome']] = ['qtd'=>0,'total'=>0];
            $servMap[$it['nome']]['qtd'] += $it['quantidade'];
            $servMap[$it['nome']]['total'] += $it['preco']*$it['quantidade'];
        } else {
            if(!isset($prodMap[$it['nome']])) $prodMap[$it['nome']] = ['qtd'=>0,'total'=>0];
            $prodMap[$it['nome']]['qtd'] += $it['quantidade'];
            $prodMap[$it['nome']]['total'] += $it['preco']*$it['quantidade'];
        }
    }
}
arsort($servMap); arsort($prodMap);
$nomeSalao = getConfig($pdo, 'nome_salao', 'Magnólia Beauty Salon');
?>
<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><title>Relatório — <?= h($nomeSalao) ?></title>
<style>
  body{font-family:'DM Sans',Arial,sans-serif;background:#fff;color:#2a2028;margin:0;}
  .box{max-width:800px;margin:20px auto;padding:20px;}
  h1{color:#c9748a;font-family:Georgia,serif;}
  table{width:100%;border-collapse:collapse;margin:10px 0 20px;}
  th,td{padding:7px 10px;border-bottom:1px solid #eee;font-size:12.5px;text-align:left;}
  th{background:#faf5f6;}
  .cards{display:flex;gap:14px;margin:16px 0;}
  .card{flex:1;border:1px solid #eee;border-radius:8px;padding:14px;text-align:center;}
  .card h3{font-size:12px;color:#8a7480;margin:0 0 6px;}
  .card p{font-size:20px;font-weight:700;margin:0;color:#c9748a;}
  .no-print{text-align:right;}
  .btn{background:#c9748a;color:#fff;border:none;padding:8px 16px;border-radius:6px;cursor:pointer;font-size:13px;}
  @media print{.no-print{display:none;}}
</style></head><body>
<div class="box">
  <div class="no-print"><button class="btn" onclick="window.print()">🖨️ Exportar / Imprimir PDF</button></div>
  <h1>✿ <?= h($nomeSalao) ?> — Relatório de Faturação</h1>
  <p>Período: <?= fmtDataBR($ini) ?> a <?= fmtDataBR($fim) ?></p>
  <div class="cards">
    <div class="card"><h3>Faturas Emitidas</h3><p><?= count($emitidas) ?></p></div>
    <div class="card"><h3>Faturas Canceladas</h3><p><?= count($canceladas) ?></p></div>
    <div class="card"><h3>Total Faturado</h3><p style="font-size:15px;"><?= fmtKz($totalFaturado) ?></p></div>
  </div>
  <h3>Serviços Mais Vendidos</h3>
  <table><thead><tr><th>Serviço</th><th>Qtd</th><th>Total</th></tr></thead><tbody>
    <?php if(!$servMap): ?><tr><td colspan="3">Sem dados.</td></tr><?php else: foreach($servMap as $nome=>$v): ?>
      <tr><td><?= h($nome) ?></td><td><?= $v['qtd'] ?></td><td><?= fmtKz($v['total']) ?></td></tr>
    <?php endforeach; endif; ?>
  </tbody></table>
  <h3>Produtos Mais Vendidos</h3>
  <table><thead><tr><th>Produto</th><th>Qtd</th><th>Total</th></tr></thead><tbody>
    <?php if(!$prodMap): ?><tr><td colspan="3">Sem dados.</td></tr><?php else: foreach($prodMap as $nome=>$v): ?>
      <tr><td><?= h($nome) ?></td><td><?= $v['qtd'] ?></td><td><?= fmtKz($v['total']) ?></td></tr>
    <?php endforeach; endif; ?>
  </tbody></table>
  <h3>Faturas no Período</h3>
  <table><thead><tr><th>Nº</th><th>Data</th><th>Cliente</th><th>Valor</th><th>Estado</th></tr></thead><tbody>
    <?php if(!$faturas): ?><tr><td colspan="5">Sem dados.</td></tr><?php else: foreach($faturas as $f): ?>
      <tr><td>#<?= str_pad($f['id'],6,'0',STR_PAD_LEFT) ?></td><td><?= fmtDataBR(substr($f['data'],0,10)) ?></td><td><?= h($f['nome_cliente'] ?? '—') ?></td><td><?= fmtKz($f['total']) ?></td><td><?= $f['estado']==='cancelada'?'Cancelada':'Emitida' ?></td></tr>
    <?php endforeach; endif; ?>
  </tbody></table>
</div>
</body></html>
