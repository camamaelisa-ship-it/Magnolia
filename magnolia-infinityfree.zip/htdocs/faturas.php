<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirLogin();
$souAdmin = tipoLogado() === 'admin';

if($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'cancelar'){
    if(!$souAdmin){
        setFlash('RN002: apenas a administradora pode cancelar faturas.','error');
        redirecionar('faturas.php');
    }
    $id = (int)$_POST['id'];
    $stmt = $pdo->prepare("UPDATE faturas SET estado='cancelada' WHERE id=?");
    $stmt->execute([$id]);
    setFlash('Fatura cancelada.','warn');
    redirecionar('faturas.php');
}

// ---------- Vista de impressão de uma fatura específica ----------
if(isset($_GET['ver'])){
    $idFat = (int)$_GET['ver'];
    $stmt = $pdo->prepare("SELECT * FROM faturas WHERE id=?");
    $stmt->execute([$idFat]);
    $fatura = $stmt->fetch();
    if(!$fatura){ setFlash('Fatura não encontrada.','error'); redirecionar('faturas.php'); }

    $stmtItens = $pdo->prepare("SELECT * FROM fatura_itens WHERE id_fatura=?");
    $stmtItens->execute([$idFat]);
    $itens = $stmtItens->fetchAll();
    $nomeSalao = getConfig($pdo, 'nome_salao', 'Magnólia Beauty Salon');
    ?>
    <!DOCTYPE html>
    <html lang="pt">
    <head><meta charset="UTF-8"><title>Fatura #<?= str_pad($fatura['id'],6,'0',STR_PAD_LEFT) ?></title>
    <style>
      body{font-family:'DM Sans',Arial,sans-serif;background:#fff;color:#2a2028;margin:0;}
      .box{max-width:700px;margin:30px auto;padding:30px;border:1px solid #ddd;}
      h1{color:#c9748a;margin-bottom:0;font-family:Georgia,serif;}
      table{width:100%;border-collapse:collapse;margin-top:16px;}
      th,td{padding:8px 10px;border-bottom:1px solid #eee;font-size:13px;text-align:left;}
      th{background:#faf5f6;}
      .total{text-align:right;color:#c9748a;margin-top:14px;}
      .no-print{text-align:right;margin-bottom:14px;}
      .btn{background:#c9748a;color:#fff;border:none;padding:8px 16px;border-radius:6px;cursor:pointer;font-size:13px;margin-left:8px;}
      @media print{.no-print{display:none;}}
    </style></head><body>
    <div class="box">
      <div class="no-print"><button class="btn" onclick="window.print()">🖨️ Exportar / Imprimir PDF</button>
      <a class="btn" style="text-decoration:none;" href="faturas.php">← Voltar</a></div>
      <h1>✿ <?= h($nomeSalao) ?></h1>
      <p>Fatura Nº <strong>#<?= str_pad($fatura['id'],6,'0',STR_PAD_LEFT) ?></strong><br>
      Data de Emissão: <?= fmtDataHoraBR($fatura['data']) ?><br>
      Estado: <strong><?= $fatura['estado']==='cancelada'?'Cancelada':'Emitida' ?></strong></p>
      <p><strong>Cliente:</strong> <?= h($fatura['nome_cliente'] ?? '—') ?><br>
      <strong>Emitido por:</strong> <?= h($fatura['emitido_por']) ?></p>
      <table>
        <thead><tr><th>Descrição</th><th>Tipo</th><th style="text-align:center;">Qtd</th><th style="text-align:right;">Preço Unit.</th><th style="text-align:right;">Subtotal</th></tr></thead>
        <tbody>
        <?php foreach($itens as $it): ?>
          <tr>
            <td><?= h($it['nome']) ?></td>
            <td><?= $it['tipo']==='servico'?'Serviço':'Produto' ?></td>
            <td style="text-align:center;"><?= $it['quantidade'] ?></td>
            <td style="text-align:right;"><?= fmtKz($it['preco']) ?></td>
            <td style="text-align:right;"><?= fmtKz($it['preco']*$it['quantidade']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <h2 class="total">Total: <?= fmtKz($fatura['total']) ?></h2>
      <p style="text-align:center;color:#999;font-size:12px;margin-top:30px;">Obrigada pela sua preferência! 💖</p>
    </div>
    </body></html>
    <?php
    exit;
}

// ---------- Listagem ----------
$busca = trim($_GET['q'] ?? '');
$sql = "SELECT * FROM faturas";
$params = [];
if($busca){ $sql .= " WHERE nome_cliente LIKE ?"; $params[] = "%$busca%"; }
$sql .= " ORDER BY data DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$faturas = $stmt->fetchAll();

$paginaAtiva = 'faturas';
$tituloPagina = 'Faturas';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Faturas</div><div class="section-sub">Histórico de vendas do salão</div></div>
</div>

<form method="GET" style="margin-bottom:14px;">
  <input type="text" name="q" placeholder="Procurar por cliente..." value="<?= h($busca) ?>" style="width:100%;max-width:320px;">
</form>

<div class="table-wrap">
  <table>
    <thead><tr><th>Nº</th><th>Cliente</th><th>Data</th><th>Itens</th><th>Valor</th><th>Estado</th><th>Acções</th></tr></thead>
    <tbody>
      <?php if(!$faturas): ?>
        <tr><td colspan="7"><div class="empty"><div class="empty-icon">🧾</div><div class="empty-text">Nenhuma fatura emitida ainda. Vá ao Carrinho para iniciar uma venda.</div></div></td></tr>
      <?php else: foreach($faturas as $f):
          $stmtCount = $pdo->prepare("SELECT COUNT(*) n FROM fatura_itens WHERE id_fatura=?");
          $stmtCount->execute([$f['id']]);
          $nItens = $stmtCount->fetch()['n'];
      ?>
        <tr>
          <td>#<?= str_pad($f['id'],6,'0',STR_PAD_LEFT) ?></td>
          <td class="td-main"><?= h($f['nome_cliente'] ?? '—') ?></td>
          <td><?= fmtDataHoraBR($f['data']) ?></td>
          <td><?= $nItens ?> item(ns)</td>
          <td style="color:var(--accent2);font-weight:600;"><?= fmtKz($f['total']) ?></td>
          <td><?= $f['estado']==='cancelada' ? '<span class="badge badge-red">Cancelada</span>' : '<span class="badge badge-green">Emitida</span>' ?></td>
          <td>
            <div class="actions" style="display:flex;gap:6px;">
              <a class="action-btn" href="faturas.php?ver=<?= $f['id'] ?>" title="Ver/Imprimir">🧾</a>
              <?php if($souAdmin && $f['estado'] !== 'cancelada'): ?>
              <form method="POST" style="display:inline;" onsubmit="return confirm('Cancelar esta fatura?');">
                <input type="hidden" name="acao" value="cancelar">
                <input type="hidden" name="id" value="<?= $f['id'] ?>">
                <button class="action-btn del" type="submit">🗑</button>
              </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; endif; ?>
    </tbody>
  </table>
</div>

<?php require 'includes/footer.php'; ?>
