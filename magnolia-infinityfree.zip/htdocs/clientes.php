<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirLogin();
$souAdmin = tipoLogado() === 'admin';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $acao = $_POST['acao'] ?? '';

    if($acao === 'salvar'){
        $id = (int)($_POST['id'] ?? 0);
        $nome = trim($_POST['nome']);
        $telefone = trim($_POST['telefone']);
        $email = trim($_POST['email'] ?? '');
        $bairro = trim($_POST['bairro'] ?? '');
        $tipoCabelo = trim($_POST['tipo_cabelo'] ?? '');
        $alergia = trim($_POST['alergia'] ?? '');
        $obs = trim($_POST['observacoes'] ?? '');

        if($nome === '' || $telefone === ''){
            setFlash('Nome e telefone são obrigatórios.','error');
            redirecionar('clientes.php');
        }

        // RN001 — verificação de duplicados por telefone/e-mail
        $stmtDup = $pdo->prepare("SELECT id, nome FROM clientes WHERE (telefone = ? OR (email <> '' AND email = ?)) AND id <> ?");
        $stmtDup->execute([$telefone, $email, $id]);
        $dup = $stmtDup->fetch();
        if($dup){
            setFlash("RN001: já existe uma cliente registada com este telefone/e-mail ({$dup['nome']}).", 'error');
            redirecionar('clientes.php');
        }

        if($id){
            $stmt = $pdo->prepare("UPDATE clientes SET nome=?, telefone=?, email=?, bairro=?, tipo_cabelo=?, alergia=?, observacoes=? WHERE id=?");
            $stmt->execute([$nome,$telefone,$email ?: null,$bairro,$tipoCabelo,$alergia,$obs,$id]);
            setFlash('Cliente actualizada!');
        } else {
            $stmt = $pdo->prepare("INSERT INTO clientes (nome,telefone,email,bairro,tipo_cabelo,alergia,observacoes) VALUES (?,?,?,?,?,?,?)");
            $stmt->execute([$nome,$telefone,$email ?: null,$bairro,$tipoCabelo,$alergia,$obs]);
            setFlash('Cliente registada!');
        }
        redirecionar('clientes.php');
    }

    if($acao === 'apagar' && $souAdmin){
        $id = (int)$_POST['id'];
        try {
            $stmt = $pdo->prepare("DELETE FROM clientes WHERE id=?");
            $stmt->execute([$id]);
            setFlash('Cliente removida (os agendamentos associados também foram removidos).','warn');
        } catch(PDOException $e){
            setFlash('Não é possível remover: esta cliente já tem faturas emitidas em seu nome.','error');
        }
        redirecionar('clientes.php');
    }
}

$busca = trim($_GET['q'] ?? '');
$sql = "SELECT * FROM clientes";
$params = [];
if($busca){
    $sql .= " WHERE nome LIKE ? OR telefone LIKE ?";
    $params = ["%$busca%", "%$busca%"];
}
$sql .= " ORDER BY nome ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$clientes = $stmt->fetchAll();

$nomeSalao = getConfig($pdo, 'nome_salao', 'Magnólia Beauty Salon');

$paginaAtiva = 'clientes';
$tituloPagina = 'Clientes';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Clientes</div><div class="section-sub">Base de dados de clientes do salão</div></div>
  <button class="btn btn-primary" onclick="abrirNovaCliente()">+ Nova Cliente</button>
</div>

<form method="GET" style="margin-bottom:14px;">
  <input type="text" name="q" placeholder="Procurar por nome ou telefone..." value="<?= h($busca) ?>" style="width:100%;max-width:320px;">
</form>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:14px;">
  <?php if(!$clientes): ?>
    <div class="empty"><div class="empty-icon">◈</div><div class="empty-text">Nenhuma cliente encontrada</div></div>
  <?php else: foreach($clientes as $c): ?>
    <div class="card">
      <div style="font-weight:600;font-size:14px;"><?= h($c['nome']) ?></div>
      <div style="font-size:12px;color:var(--text3);margin-top:4px;line-height:1.7;">
        📞 <?= h($c['telefone']) ?><br>
        <?php if($c['email']): ?>✉️ <?= h($c['email']) ?><br><?php endif; ?>
        <?php if($c['bairro']): ?>📍 <?= h($c['bairro']) ?><br><?php endif; ?>
        <?php if($c['tipo_cabelo']): ?>💇 <?= h($c['tipo_cabelo']) ?><?php endif; ?>
      </div>
      <?php if($c['alergia']): ?><div class="sol-obs">⚠️ Alergia: <?= h($c['alergia']) ?></div><?php endif; ?>
      <div class="client-footer">
        <button class="btn-whatsapp btn-sm" onclick="whatsappCliente('<?= formatarTelWhatsApp($c['telefone']) ?>','<?= h(addslashes($c['nome'])) ?>')">💬 WhatsApp</button>
        <?php if($souAdmin): ?>
          <button class="btn btn-ghost btn-sm" onclick='abrirEditarCliente(<?= json_encode($c) ?>)'>✎ Editar</button>
          <form method="POST" style="display:inline;" onsubmit="return confirm('Remover esta cliente?');">
            <input type="hidden" name="acao" value="apagar">
            <input type="hidden" name="id" value="<?= $c['id'] ?>">
            <button class="btn btn-danger btn-sm" type="submit">🗑</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  <?php endforeach; endif; ?>
</div>

<!-- MODAL: NOVA/EDITAR CLIENTE -->
<div class="modal-overlay" id="modal-cliente">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title" id="modal-cl-title">Nova Cliente</div>
      <button class="modal-close" onclick="fecharModal('modal-cliente')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="acao" value="salvar">
        <input type="hidden" name="id" id="cl-id">
        <div class="form-group"><label>Nome <span class="req">*</span></label><input type="text" name="nome" id="cl-nome" required></div>
        <div class="form-row">
          <div class="form-group"><label>Telefone <span class="req">*</span></label><input type="text" name="telefone" id="cl-tel" required></div>
          <div class="form-group"><label>E-mail</label><input type="email" name="email" id="cl-email"></div>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Bairro</label><input type="text" name="bairro" id="cl-bairro"></div>
          <div class="form-group"><label>Tipo de Cabelo</label><input type="text" name="tipo_cabelo" id="cl-cabelo"></div>
        </div>
        <div class="form-group"><label>Alergias</label><input type="text" name="alergia" id="cl-alergia"></div>
        <div class="form-group"><label>Observações</label><textarea name="observacoes" id="cl-obs"></textarea></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="fecharModal('modal-cliente')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
      </div>
    </form>
  </div>
</div>

<script>
function abrirNovaCliente(){
  document.getElementById('modal-cl-title').textContent = 'Nova Cliente';
  ['cl-id','cl-nome','cl-tel','cl-email','cl-bairro','cl-cabelo','cl-alergia','cl-obs'].forEach(id=>document.getElementById(id).value='');
  abrirModal('modal-cliente');
}
function abrirEditarCliente(c){
  document.getElementById('modal-cl-title').textContent = 'Editar Cliente';
  document.getElementById('cl-id').value = c.id;
  document.getElementById('cl-nome').value = c.nome;
  document.getElementById('cl-tel').value = c.telefone;
  document.getElementById('cl-email').value = c.email || '';
  document.getElementById('cl-bairro').value = c.bairro || '';
  document.getElementById('cl-cabelo').value = c.tipo_cabelo || '';
  document.getElementById('cl-alergia').value = c.alergia || '';
  document.getElementById('cl-obs').value = c.observacoes || '';
  abrirModal('modal-cliente');
}
function whatsappCliente(tel, nome){
  const salao = <?= json_encode($nomeSalao) ?>;
  const primeiroNome = nome.split(' ')[0];
  const msg = `Olá ${primeiroNome}! 👋 Aqui é do *${salao}*. 🌸`;
  abrirWhatsApp(tel, msg);
}
</script>

<?php require 'includes/footer.php'; ?>
