<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
exigirLogin();
$souAdmin = tipoLogado() === 'admin';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $acao = $_POST['acao'] ?? '';

    if($acao === 'salvar'){
        $id = (int)($_POST['id'] ?? 0);
        $nome = trim($_POST['nome']);
        $categoria = trim($_POST['categoria']);
        $preco = (float)$_POST['preco'];
        $duracao = (int)$_POST['duracao'];
        $descricao = trim($_POST['descricao'] ?? '');

        if($nome === '' || $categoria === '' || $preco <= 0 || $duracao <= 0){
            setFlash('Preencha todos os campos correctamente.','error');
            redirecionar('servicos.php');
        }

        // RN001 — nome do serviço deve ser único
        $stmtDup = $pdo->prepare("SELECT id FROM servicos WHERE LOWER(nome) = LOWER(?) AND id <> ?");
        $stmtDup->execute([$nome, $id]);
        if($stmtDup->fetch()){
            setFlash('RN001: já existe um serviço com este nome.','error');
            redirecionar('servicos.php');
        }

        if($id){
            $stmt = $pdo->prepare("UPDATE servicos SET nome=?, categoria=?, preco=?, duracao=?, descricao=? WHERE id=?");
            $stmt->execute([$nome,$categoria,$preco,$duracao,$descricao,$id]);
            setFlash('Serviço actualizado!');
        } else {
            $stmt = $pdo->prepare("INSERT INTO servicos (nome,categoria,preco,duracao,descricao) VALUES (?,?,?,?,?)");
            $stmt->execute([$nome,$categoria,$preco,$duracao,$descricao]);
            setFlash('Serviço criado!');
        }
        redirecionar('servicos.php');
    }

    if($acao === 'apagar' && $souAdmin){
        $id = (int)$_POST['id'];
        try {
            $stmt = $pdo->prepare("DELETE FROM servicos WHERE id=?");
            $stmt->execute([$id]);
            setFlash('Serviço removido.','warn');
        } catch(PDOException $e){
            setFlash('Não é possível remover: este serviço já está associado a agendamentos ou faturas.','error');
        }
        redirecionar('servicos.php');
    }
}

$filtroCat = $_GET['categoria'] ?? '';
$sql = "SELECT * FROM servicos";
$params = [];
if($filtroCat){ $sql .= " WHERE categoria = ?"; $params[] = $filtroCat; }
$sql .= " ORDER BY nome ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$servicos = $stmt->fetchAll();

$paginaAtiva = 'servicos';
$tituloPagina = 'Serviços';
require 'includes/header.php';
?>

<div class="section-header">
  <div><div class="section-title">Serviços</div><div class="section-sub">Catálogo de serviços do salão</div></div>
  <button class="btn btn-primary" onclick="abrirNovoServico()">+ Novo Serviço</button>
</div>

<form method="GET" class="filters" style="margin-bottom:14px;">
  <select name="categoria" onchange="this.form.submit()">
    <option value="">Todas as categorias</option>
    <?php foreach(['cabelo','unhas','pele'] as $cat): ?>
      <option value="<?= $cat ?>" <?= $filtroCat===$cat?'selected':'' ?>><?= ucfirst($cat) ?></option>
    <?php endforeach; ?>
  </select>
</form>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px;">
  <?php if(!$servicos): ?>
    <div class="empty"><div class="empty-icon">✦</div><div class="empty-text">Nenhum serviço encontrado</div></div>
  <?php else: foreach($servicos as $s): ?>
    <div class="card">
      <div style="font-weight:600;font-size:14px;"><?= h($s['nome']) ?></div>
      <div style="font-size:12px;color:var(--text3);margin:6px 0;"><?= h($s['descricao']) ?></div>
      <div style="display:flex;justify-content:space-between;font-size:13px;margin-top:8px;">
        <span style="color:var(--accent2);font-weight:600;"><?= fmtKz($s['preco']) ?></span>
        <span><?= (int)$s['duracao'] ?> min</span>
      </div>
      <?php if($souAdmin): ?>
      <div class="client-footer">
        <button class="btn btn-ghost btn-sm" onclick='abrirEditarServico(<?= json_encode($s) ?>)'>✎ Editar</button>
        <form method="POST" style="display:inline;" onsubmit="return confirm('Remover este serviço?');">
          <input type="hidden" name="acao" value="apagar">
          <input type="hidden" name="id" value="<?= $s['id'] ?>">
          <button class="btn btn-danger btn-sm" type="submit">🗑</button>
        </form>
      </div>
      <?php endif; ?>
    </div>
  <?php endforeach; endif; ?>
</div>

<div class="modal-overlay" id="modal-servico">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title" id="modal-sv-title">Novo Serviço</div>
      <button class="modal-close" onclick="fecharModal('modal-servico')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="acao" value="salvar">
        <input type="hidden" name="id" id="sv-id">
        <div class="form-group"><label>Nome <span class="req">*</span></label><input type="text" name="nome" id="sv-nome" required></div>
        <div class="form-group">
          <label>Categoria <span class="req">*</span></label>
          <select name="categoria" id="sv-cat" required>
            <option value="cabelo">Cabelo</option>
            <option value="unhas">Unhas</option>
            <option value="pele">Pele</option>
          </select>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Preço (Kz) <span class="req">*</span></label><input type="number" name="preco" id="sv-preco" min="0" step="1" required></div>
          <div class="form-group"><label>Duração (min) <span class="req">*</span></label><input type="number" name="duracao" id="sv-dur" min="1" required></div>
        </div>
        <div class="form-group"><label>Descrição</label><textarea name="descricao" id="sv-desc"></textarea></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-ghost" onclick="fecharModal('modal-servico')">Cancelar</button>
        <button type="submit" class="btn btn-primary">Guardar</button>
      </div>
    </form>
  </div>
</div>

<script>
function abrirNovoServico(){
  document.getElementById('modal-sv-title').textContent = 'Novo Serviço';
  ['sv-id','sv-nome','sv-preco','sv-dur','sv-desc'].forEach(id=>document.getElementById(id).value='');
  document.getElementById('sv-cat').value = 'cabelo';
  abrirModal('modal-servico');
}
function abrirEditarServico(s){
  document.getElementById('modal-sv-title').textContent = 'Editar Serviço';
  document.getElementById('sv-id').value = s.id;
  document.getElementById('sv-nome').value = s.nome;
  document.getElementById('sv-cat').value = s.categoria;
  document.getElementById('sv-preco').value = s.preco;
  document.getElementById('sv-dur').value = s.duracao;
  document.getElementById('sv-desc').value = s.descricao || '';
  abrirModal('modal-servico');
}
</script>

<?php require 'includes/footer.php'; ?>
