<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';

$sucesso = false;
$erro = '';

if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $nome = trim($_POST['nome'] ?? '');
    $telefone = trim($_POST['telefone'] ?? '');
    $idServico = (int)($_POST['id_servico'] ?? 0);
    $data = $_POST['data'] ?? '';
    $hora = $_POST['hora'] ?? '';
    $obs = trim($_POST['obs'] ?? '');

    if(!$nome || !$telefone || !$idServico || !$data || !$hora){
        $erro = 'Preencha todos os campos obrigatórios.';
    } elseif(!preg_match('/^[0-9\s]{9,15}$/', $telefone)){
        $erro = 'Introduza um telefone válido (9 a 15 dígitos).';
    } else {
        $stmt = $pdo->prepare("INSERT INTO solicitacoes (nome,telefone,id_servico,data,hora,observacoes,estado) VALUES (?,?,?,?,?,?,'pendente')");
        $stmt->execute([$nome,$telefone,$idServico,$data,$hora,$obs]);
        $sucesso = true;
        $servicoNome = '';
        $stmtServ = $pdo->prepare("SELECT nome FROM servicos WHERE id=?");
        $stmtServ->execute([$idServico]);
        $servicoNome = $stmtServ->fetch()['nome'] ?? 'serviço';
    }
}

$servicos = $pdo->query("SELECT id, nome, preco FROM servicos ORDER BY nome ASC")->fetchAll();
$nomeSalao = getConfig($pdo, 'nome_salao', 'Magnólia Beauty Salon');
$waNumero = '244' . getConfig($pdo, 'wa_numero', '958391756');
?>
<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Marcar Agendamento — <?= h($nomeSalao) ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div id="login-screen">
  <div class="login-box">
    <div class="login-logo">✿</div>
    <div class="login-title"><?= h($nomeSalao) ?></div>

    <?php if($sucesso): ?>
      <div style="text-align:center;padding:10px 0 20px;">
        <div style="font-size:40px;margin-bottom:10px;">✅</div>
        <div style="font-size:15px;font-weight:600;color:var(--text);margin-bottom:8px;">Pedido enviado com sucesso!</div>
        <div style="font-size:12.5px;color:var(--text3);line-height:1.6;">
          Olá <?= h($nome) ?>, recebemos o seu pedido para <strong><?= h($servicoNome) ?></strong> no dia <?= fmtDataBR($data) ?> às <?= h($hora) ?>.<br><br>
          A administração vai analisar e enviar-lhe a confirmação pelo WhatsApp em breve. 🌸
        </div>
      </div>
      <button class="btn btn-primary" style="width:100%;" onclick="window.location.href='public_agendar.php'">Fazer novo pedido</button>
      <div class="staff-access-link" onclick="window.location.href='login.php'">← Voltar ao acesso da equipa</div>
    <?php else: ?>
      <div class="login-sub" style="margin-bottom:16px;">Marque já o seu horário connosco</div>
      <?php if($erro): ?><div class="pin-error" style="display:block;"><?= h($erro) ?></div><?php endif; ?>
      <form method="POST">
        <div class="form-group"><label>Nome completo <span class="req">*</span></label><input type="text" name="nome" value="<?= h($_POST['nome'] ?? '') ?>" required></div>
        <div class="form-group"><label>Telefone (WhatsApp) <span class="req">*</span></label><input type="tel" name="telefone" placeholder="923 456 789" value="<?= h($_POST['telefone'] ?? '') ?>" required></div>
        <div class="form-group">
          <label>Serviço pretendido <span class="req">*</span></label>
          <select name="id_servico" required>
            <option value="">Seleccionar serviço</option>
            <?php foreach($servicos as $s): ?>
              <option value="<?= $s['id'] ?>"><?= h($s['nome']) ?> (<?= fmtKz($s['preco']) ?>)</option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-row">
          <div class="form-group"><label>Data preferida <span class="req">*</span></label><input type="date" name="data" min="<?= hoje() ?>" required></div>
          <div class="form-group"><label>Hora preferida <span class="req">*</span></label><input type="time" name="hora" required></div>
        </div>
        <div class="form-group"><label>Observações</label><textarea name="obs" placeholder="Alguma preferência ou informação adicional?"></textarea></div>
        <button type="submit" class="btn btn-primary" style="width:100%;padding:14px;font-size:14px;margin:10px 0;">Enviar Pedido</button>
      </form>
      <button class="btn-whatsapp" style="width:100%;padding:14px;font-size:14px;" onclick="abrirWADireto()">💬 Falar no WhatsApp</button>
      <div class="staff-access-link" onclick="window.location.href='login.php'">🔒 Acesso da Equipa</div>
    <?php endif; ?>
  </div>
</div>

<script>
function abrirWADireto(){
  const salao = <?= json_encode($nomeSalao) ?>;
  const tel = <?= json_encode($waNumero) ?>;
  const msg = `Olá! 👋 Vim através do site do *${salao}* e gostaria de mais informações. 🌸`;
  const isAndroid = /Android/i.test(navigator.userAgent);
  const texto = encodeURIComponent(msg);
  if(isAndroid){
    const linkWeb = `https://wa.me/${tel}?text=${texto}`;
    window.location.href = `intent://send?phone=${tel}&text=${texto}#Intent;scheme=whatsapp;package=com.whatsapp;S.browser_fallback_url=${encodeURIComponent(linkWeb)};end`;
  } else {
    const a = document.createElement('a');
    a.href = `https://wa.me/${tel}?text=${texto}`; a.rel='noopener'; a.style.display='none';
    document.body.appendChild(a); a.click();
    setTimeout(()=>a.remove(), 500);
  }
}
</script>
</body>
</html>
